"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 2162:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ BottomCTA)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3947);
/* harmony import */ var _utils_DonateButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8039);





const BottomCTA = ()=>{
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { data , loading , error  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_3__/* .getTexts */ .r)(locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "flex justify-center mt-24 mb-24 px-6 xl:px-0",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "flex justify-center flex-col max-w-[1216px] w-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col justify-center px-0 xl:px-9 overflow-visible",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-center gap-4 flex-col md:flex-row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex w-full md:w-fit justify-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_DonateButton__WEBPACK_IMPORTED_MODULE_4__/* .DonateButton */ .H, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex w-full md:w-fit justify-center text-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "cursor-pointer font-proximaNova400 border-solid border-blue-500 border-2 text-base md:text-xl py-[12px] px-2 md:px-[32px] rounded-[50px] uppercase",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/how",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-blue-500",
                                        children: data["volunteer-with-us"]
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};


/***/ }),

/***/ 8678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ ClubAbout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_Gallery__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6588);
/* harmony import */ var _utils_HeadingToggler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3884);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_Gallery__WEBPACK_IMPORTED_MODULE_1__]);
_utils_Gallery__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ClubAbout = ()=>{
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { data , loading , error  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_4__/* .getTexts */ .r)(locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "flex justify-center mb-24 md:mb-28 pl-6 xl:px-0",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-center flex-col max-w-[1216px] w-full",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "md:pr-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_HeadingToggler__WEBPACK_IMPORTED_MODULE_2__/* .HeadingToggler */ .B, {
                        heading: data["home-about-club"],
                        togglerPrevClass: "gallery-prev",
                        togglerNextClass: "gallery-next"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-between",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Gallery__WEBPACK_IMPORTED_MODULE_1__/* .Gallery */ .r, {})
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "R": () => (/* binding */ ClubQuestions)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/images/volonter_products.webp
/* harmony default export */ const volonter_products = ({"src":"/_next/static/media/volonter_products.2e4a706d.webp","height":399,"width":562,"blurDataURL":"data:image/webp;base64,UklGRqAAAABXRUJQVlA4WAoAAAAQAAAABwAABQAAQUxQSDEAAAAAAgCUeIHXOAAAOv///f+FNA7P//v//NZ3x//8//365on7////////6k+e/vbLwNWfAFZQOCBIAAAA0AEAnQEqCAAGAAJAOCWYAnQA9Kwx/wAA/vdhgAAjhmyy7eb6PJ9N7DT/4YjoUKQHKSC09n9cAefb2m7XUj4d1ockjwwRAAAA"});
;// CONCATENATED MODULE: ./assets/images/facebook_sharing.webp
/* harmony default export */ const facebook_sharing = ({"src":"/_next/static/media/facebook_sharing.281152d9.webp","height":399,"width":429,"blurDataURL":"data:image/webp;base64,UklGRsAAAABXRUJQVlA4WAoAAAAQAAAABwAABgAAQUxQSDkAAAAAAAAvclQDAwAbUe3//44AATJ/+/z/9SsAH8z/+//OsD4Y0Mr/6Fi1o4fQ3f/GnOrFMF+yn4KCh1EAVlA4IGAAAADwAQCdASoIAAcAAkA4JQBOhggALSVkMiAA/vgIvwN828RJunWU1FPv1Q7Ge7jiwZlIr60vKgYO4m+GIjWQ37MhPJWBiLwEXd5+81WP7Tb/gZwZkyZEtTvvMsX+TW0gAAA="});
;// CONCATENATED MODULE: ./assets/images/Vector.svg
/* harmony default export */ const Vector = ({"src":"/_next/static/media/Vector.45c2318c.svg","height":17,"width":10});
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
// EXTERNAL MODULE: ./components/utils/DonateButton.jsx + 1 modules
var DonateButton = __webpack_require__(8039);
;// CONCATENATED MODULE: ./components/sections/home/ClubQuestions.jsx








const ClubQuestions = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "flex justify-center mb-[72px] md:mb-28 px-6 xl:px-0",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-center flex-col max-w-[1216px] w-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: " font-proximaNova500 text-4xl md:text-[37px] lg:text-[52px] sm:text-[28px] uppercase w-full leading-[54px] xl:leading-10 tracking-wider pb-0 md:pb-11 xl:pb-36 flex justify-center mb-[9px] xl:text-center",
                        children: [
                            data["home-assosiation"],
                            "  "
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " w-full flex flex-col-reverse md:flex-row items-center justify-between md:justify-center xl:justify-start gap-0 xl:gap-[80px] px-5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "pr-[20px] md:w-1/2 lg:mt-[-50px] ",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                        className: "font-proximaNova400 text-[26px] md:text-3xl lg:text-4xl uppercase",
                                        children: [
                                            data["home-are-you"],
                                            "  ",
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "text-blue-500 ",
                                                children: [
                                                    data["home-going-to"],
                                                    "  "
                                                ]
                                            }),
                                            data["home-canada-question"]
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex text-xl font-proximaNova300 mt-[32px]",
                                        children: data["home-immigration"]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tablets:w-[355px] sm:w-[349px] mt-[32px]",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(DonateButton/* DonateButton */.H, {
                                            text: data["go-to-shop"],
                                            img: Vector,
                                            link: data["link-to-shop"]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "md:w-[400px] lg:w-[562px] w-1/2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: volonter_products,
                                    alt: "Woman in doubt",
                                    width: 562,
                                    height: 400
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center justify-between flex-col md:flex-row xl:justify-between gap-0 xl:gap-28 pt-20",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "pb-12 md:pb-0 w-1/2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: facebook_sharing,
                                    alt: "ladder climbing",
                                    width: 400,
                                    height: 400
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " md:w-1/2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                        className: "font-proximaNova400 text-[26px] md:text-4xl pl-[10px] uppercase",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "text-500 md:text-[30px] lg:text-[36px]",
                                                children: [
                                                    data["home-already"],
                                                    " ",
                                                    " "
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "text-blue-500 md:text-[30px] lg:text-[36px]",
                                                children: [
                                                    data["home-shop-us"],
                                                    " "
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: " md:text-[30px] lg:text-[36px]",
                                                children: [
                                                    data["home-in-canada"],
                                                    " "
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "pl-2 md:pl-4 pt-6 md:pt-10 font-proximaNova300 text-xl md:text-[24px] leading-9",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "md:w-[289px] mobile-l:w-[280px] mt-[32px]",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(DonateButton/* DonateButton */.H, {
                                            link: data["facebook-navigation"],
                                            img: Vector,
                                            text: data["go-to-our-group"]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "G": () => (/* binding */ HomeFront)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(543);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/utils/FilledButton.jsx


const FilledButton = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: `${props.href ? props.href : "/"}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `rounded-[50px] py-3 md:py-4 w-[152px] md:w-[230px] flex
      justify-center text-center ${props.bgColor} cursor-pointer`,
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `uppercase text-${props.textColor} font-proximaNova400
          text-base md:text-2xl`,
                children: props.text
            })
        })
    });
};

;// CONCATENATED MODULE: ./assets/images/Ukraine.webp
/* harmony default export */ const Ukraine = ({"src":"/_next/static/media/Ukraine.2d3cac1b.webp","height":1059,"width":1072,"blurDataURL":"data:image/webp;base64,UklGRsgAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAAAAABJgCJ8AAAjS6H/99QPEAbl//3//PVVKc7/+/r/0wCG9vr8+/r/iwB9//z//3UUAHmI6czDUwACAAB1MgAVAABWUDggYAAAABACAJ0BKggACAACQDglsAJ0MEvBmXyeqGAA/uicKUNTqSaJm3l6oZGWwFEHNXnvSe1QUKrGUzDCKW+dXU/7de9P8Q4f/+z2O6xr8Q/7WLfHf6+3uv+clXU/77n94l4AAA=="});
;// CONCATENATED MODULE: ./components/sections/home/HomeFront.jsx






const HomeFront = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data: dataFrom100 , loading: loadingFrom100 , error: errorFrom100  } = (0,getTexts/* getTexts */.r)(locale, 100);
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading || loadingFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error || errorFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "home-front-section min-h-[calc(121vh)] flex justify-center items-center mb-[47px] bg-cover bg-center bg-no-repeat 2xl:px-8 px-8 pb-8 tablets:pb-0",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between gap-3 lg:gap-6 flex-col tablets:flex-row w-full tablets:w-auto md:mt-[20px] lg:mt-[-110px]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:max-w-[453px] lg:max-w-[440px] max-w-full 2xl:max-w-[510px] flex flex-col gap-6 md:gap-8 mt-[.5rem]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: "font-proximaNova300 text-[34px] md:text-[35px] lg:text-[38px] leading-[40px] md:leading-[65px] first-letter:tracking-wide",
                                children: [
                                    data["home-evening"],
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-blue-500 text-[43px] md:text-[44px] lg:text-[48px] ",
                                        children: data["home-upper-title-blue"]
                                    }),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-yellow-300 text-[43px] md:text-[44px] lg:text-[48px] ",
                                        children: data["home-upper-title-yellow"]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-proximaNova300 text-xl md:text-2xl",
                                children: data["home-upper-introduction"]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-end items-center gap-6 md:gap-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: "border border-solid border-gray-900 max-w-[92px] w-[92px]"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(FilledButton, {
                                        href: "/info/1",
                                        text: data["home-upper-next"],
                                        textColor: "gray-100",
                                        bgColor: "bg-[#006DB6]"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-col justify-center items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " object-cover",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: Ukraine,
                                    alt: "flag",
                                    width: 454,
                                    height: 398.34,
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " tablets-m:mx-[10px] text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-blue-500 text-[39px] 2xl:text-[36px] xl:text-[22px] md:text-[18px] smallest-phones:text-[16px] lg:text-[21px] tablets-m:text-[11px] ",
                                        children: dataFrom100["logo-ukrainian-first"]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-blue-500 text-[43px] text-center 2xl:text-[47px] xl:text-[29px] md:text-[24px] smallest-phones:text-[21px] lg:text-[27px] tablets-m:text-[15px] ",
                                        children: dataFrom100["logo-ukrainian-second"]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " xl:max-w-[453px] max-w-full 2xl:max-w-[510px] w-full lg:pt-[5rem] lg:max-w-[440px] hidden md:flex flex-col gap-8 mt-0 md:mt-[8.4rem] lg:mb-[-170px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-start items-center gap-6 md:gap-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(FilledButton, {
                                        href: "/how",
                                        text: data["home-bottom-next"],
                                        textColor: "color-[#002049E5]",
                                        bgColor: "bg-[#F9EA35]"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: "border border-solid border-gray-900 max-w-[92px] w-[92px]"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-proximaNova300 text-2xl",
                                children: data["home-bottom-introduction"]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: "font-proximaNova300 uppercase text-[39px] leading-[65px] xl:leading-[64px] md:leading-[46px] tracking-wide md:text-[25px] lg:text-[32px] xl:text-[34px]",
                                children: [
                                    data["home-bottom-subtitle"],
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-blue-500 text-[55px] 2xl:text-[55px] xl:text-[52px] lg:text-[51px] md:text-[40px] uppercase",
                                        children: data["home-bottom-title-bold"]
                                    }),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-gray-900 text-[55px] 2xl:text-[55px] xl:text-[52px] lg:text-[51px] md:text-[40px] uppercase",
                                        children: data["home-bottom-title"]
                                    }),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-yellow-300 text-[55px] 2xl:text-[55px] xl:text-[52px] lg:text-[51px] md:text-[40px] uppercase",
                                        children: data["home-help"]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-w-full flex md:hidden flex-col gap-6 mt-2 tablets:mt-20",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: "font-proximaNova300 text-[23px] uppercase leading-[24px] tracking-wider",
                                children: [
                                    data["home-bottom-subtitle"],
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-blue-500 text-[35px] md:text-[62.81px] uppercase",
                                        children: data["home-bottom-title-bold"]
                                    }),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-blue-900 text-[35px] md:text-[62.81px] uppercase",
                                        children: data["home-bottom-title"]
                                    }),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-yellow-300 text-[35px] md:text-[62.81px] uppercase",
                                        children: data["home-help"]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-proximaNova300 text-[19px] leading-[30px] tracking-wider",
                                children: data["home-bottom-introduction"]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-end items-center gap-6 md:gap-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: "border border-solid border-gray-900 max-w-[92px] w-[92px]"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(FilledButton, {
                                        href: "/how",
                                        text: data["home-bottom-next"],
                                        textColor: "black-100",
                                        bgColor: "bg-yellow-300"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 3298:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "p": () => (/* binding */ Quote)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/images/quote.svg
/* harmony default export */ const quote = ({"src":"/_next/static/media/quote.9f658f78.svg","height":94,"width":94});
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
;// CONCATENATED MODULE: ./components/sections/home/Quote.jsx





const Quote = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "flex justify-center mb-12 mt-0 md:mt-36 px-6 xl:px-0",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex justify-center flex-col max-w-[1216px] w-full",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col justify-center rounded-3xl overflow-visible shadow-[0px_2px_32px_rgba(0,32,73,0.13)] px-4 md:px-9 bg-white",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center -translate-y-12 z-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: quote,
                            alt: "quote"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "-mt-5 pb-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: "text-left md:text-center font-proximaNova300 text-base md:text-lg leading-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "max-w-2xl w-full inline-block",
                                    children: [
                                        data["home-we-are"],
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        data["home-membership"]
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                data["home-focus"],
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "max-w-2xl w-full inline-block",
                                    children: data["home-finally"]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 3388:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ UpcomingEvents)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3947);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3877);
/* harmony import */ var _utils_HeadingToggler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3884);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_6__, swiper__WEBPACK_IMPORTED_MODULE_7__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_6__, swiper__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const GET_MOST_RECENT_POSTS_QUERY = _apollo_client__WEBPACK_IMPORTED_MODULE_5__.gql`
  query getRecentPosts {
    posts(
      where: { category: { slug: "event" } }
      orderBy: createdAt_DESC
      last: 10
    ) {
      title
      tags {
        name
        slug
      }
      excerpt
      featuredImage {
        url
      }
      address
      slug
      createdAt
      localizations(locales: uk_UA) {
        title
        excerpt
        address
        tags {
          name
        }
      }
    }
  }
`;
const UpcomingEvents = ()=>{
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { loading , error , data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_5__.useQuery)(GET_MOST_RECENT_POSTS_QUERY);
    const { data: dataT , loading: loadingT , error: errorT  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_4__/* .getTexts */ .r)(locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: "Loading..."
    });
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: "Error"
    });
    if (loadingT) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (errorT) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "flex justify-center mb-16 md:mb-28 pl-6 md:px-6 xl:px-0",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-center flex-col max-w-[1260px] w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_HeadingToggler__WEBPACK_IMPORTED_MODULE_8__/* .HeadingToggler */ .B, {
                        heading: dataT["home-upcoming-events"],
                        togglerPrevClass: "event-prev",
                        togglerNextClass: "event-next"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-between gap-2 xl:gap-0 -ml-[23px] md:ml-0 -mt-14",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__.Swiper, {
                            className: "home-events-swiper h-full",
                            breakpoints: {
                                100: {
                                    slidesPerView: "auto",
                                    spaceBetween: 8
                                },
                                700: {
                                    spaceBetween: 8
                                },
                                800: {
                                    spaceBetween: 30
                                },
                                1030: {
                                    slidesPerView: 3,
                                    centeredSlides: false,
                                    spaceBetween: 60
                                }
                            },
                            pagination: {
                                clickable: true
                            },
                            navigation: {
                                prevEl: ".event-prev",
                                nextEl: ".event-next"
                            },
                            modules: [
                                swiper__WEBPACK_IMPORTED_MODULE_7__.Navigation,
                                swiper__WEBPACK_IMPORTED_MODULE_7__.Pagination
                            ],
                            children: data.posts.map((post)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__.SwiperSlide, {
                                    className: "py-10",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "shadow-[0px_2px_22px_rgba(0,32,73,0.13)] w-full max-h-full h-full overflow-hidden bg-gray-100 rounded-3xl mt-6 flex flex-col justify-start",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full flex flex-col",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "w-full min-h-[200px] md:min-h-[256px] object-cover max-h-[200px] md:max-h-[256px]",
                                                    src: post.featuredImage.url,
                                                    alt: locale == "ua" ? post?.localizations[0]?.title : post.title,
                                                    title: locale == "ua" ? post.localizations[0]?.title : post.title,
                                                    loading: "lazy"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "px-4 lg:px-6 pt-6 flex flex-col justify-between h-full",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: `font-proximaNova200 text-yellow-900
                        px-6 py-2 rounded-[20px] ${post.tags[0]?.name ? "bg-yellow-100" : "bg-none"}`,
                                                                    children: locale == "ua" ? post.localizations[0]?.tags[0]?.name : post.tags[0]?.name
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "pt-8",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "font-proximaNova500 uppercase text-xl md:text-2xl",
                                                                        children: locale == "ua" ? post?.localizations[0]?.title : post.title
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "pr-4 md:pr-0 font-proximaNova200 text-base md:text-lg pt-2 leading-[18px]",
                                                                        children: locale == "ua" ? post?.localizations[0]?.excerpt : post.excerpt
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-full md:w-auto flex justify-between items-center pt-10 pb-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "font-proximaNova200 text-base text-gray-500 md:text-lg leading-[18px]",
                                                                    children: moment__WEBPACK_IMPORTED_MODULE_2___default()(post.createdAt).format("MMM DD, YYYY")
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    href: `/posts/${post.slug}`,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "bg-yellow-500 text-black-100 py-3 px-4 lg:px-10 rounded-[64px] font-proximaNova400 text-base md:text-lg text-center cursor-pointer",
                                                                        children: locale == "ua" ? "\u0427\u0438\u0442\u0430\u0442\u0438 \u0434\u0430\u043B\u0456" : "Read more"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, post.title))
                        })
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6588:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ Gallery)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3015);
/* harmony import */ var fslightbox_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9354);
/* harmony import */ var fslightbox_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(fslightbox_react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_3__, swiper_react__WEBPACK_IMPORTED_MODULE_4__]);
([swiper__WEBPACK_IMPORTED_MODULE_3__, swiper_react__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const GET_GALLERY_IMAGES_QUERY = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`
  query getGalleryImages {
    galleries (
      orderBy: createdAt_DESC,
      last: 16
    ) {
    picture {
      url
    }
    }
  }
`;
const Gallery = ()=>{
    const { loading , error , data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(GET_GALLERY_IMAGES_QUERY);
    const { 0: toggler , 1: setToggler  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: img , 1: setImg  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const handleOpenImg = (img)=>{
        setToggler(!toggler);
        setImg(img);
    };
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: "Loading..."
    });
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: "Error"
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
            breakpoints: {
                100: {
                    slidesPerView: 1.2,
                    spaceBetween: 18
                },
                768: {
                    slidesPerView: 3
                }
            },
            spaceBetween: 30,
            autoplay: {
                delay: 2000,
                disableOnInteraction: false
            },
            navigation: {
                prevEl: ".gallery-prev",
                nextEl: ".gallery-next"
            },
            modules: [
                swiper__WEBPACK_IMPORTED_MODULE_3__.Pagination,
                swiper__WEBPACK_IMPORTED_MODULE_3__.Navigation,
                swiper__WEBPACK_IMPORTED_MODULE_3__.Autoplay
            ],
            className: "home-gallery-swiper ",
            children: [
                img && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((fslightbox_react__WEBPACK_IMPORTED_MODULE_5___default()), {
                    toggler: toggler,
                    sources: img ? [
                        img
                    ] : data.galleries.map((item)=>item.picture.url)
                }),
                data.galleries.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            onClick: ()=>handleOpenImg(item.picture.url),
                            src: item.picture.url,
                            className: "rounded-[16px] w-full max-w-[376px] h-full max-h-[244px] object-cover hover:max-w-[413.6px] origin-center transition-all",
                            loading: "lazy",
                            alt: "Ukraine"
                        })
                    }, i))
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "u": () => (/* binding */ ThankYouModal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "@mui/material/Box"
const Box_namespaceObject = require("@mui/material/Box");
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Modal"
const Modal_namespaceObject = require("@mui/material/Modal");
var Modal_default = /*#__PURE__*/__webpack_require__.n(Modal_namespaceObject);
;// CONCATENATED MODULE: ./hooks/useNextQueryParam.js


function useNextQueryParam(key) {
    const router = (0,router_.useRouter)();
    return external_react_.useMemo(()=>{
        const res = router.asPath.match(new RegExp(`[&?]${key}=(.*)(&|$)`)) || [];
        return res[1];
    }, [
        router.asPath
    ]);
}

// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
;// CONCATENATED MODULE: ./components/utils/ThankYouModal.jsx







const ThankYouModal = ()=>{
    const router = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(router.locale);
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(useNextQueryParam("ty") || false);
    const handleClose = ()=>setOpen(false);
    let ty = router.query["ty"];
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    const style = {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        bgcolor: "background.paper",
        boxShadow: 24,
        p: 4,
        borderRadius: "24px"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx((Modal_default()), {
            open: open,
            onClose: handleClose,
            "aria-labelledby": "modal-modal-title",
            "aria-describedby": "modal-modal-description",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                sx: style,
                className: "flex flex-col justify-center items-center w-[330px] md:w-[480px] h-[458px] md:h-[608px]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center -mt-3 w-[184px] md:w-64",
                        children: ty === "0" ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/not-success-image.svg",
                            alt: "not successful"
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/thank-you-image.svg",
                            alt: "success"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col items-center justify-center pt-8 md:pt-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                className: `font-proximaNova500 text-4xl md:text-5xl leading-[100%]
            uppercase text-center ${ty === "0" ? "text-red-500" : "text-gray-900"}`,
                                children: ty === "0" ? data["paypal-oh"] : data["paypal-thank"]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-proximaNova200 text-xl md:text-2xl leading-9 text-gray-900 text-center pt-4 md:pt-6",
                                children: ty === "0" ? data["paypal-wrong"] : data["paypal-donat-success"]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: `font-proximaNova200 text-xl md:text-2xl leading-9
            text-center ${ty === "0" ? "text-gray-900" : "text-blue-500"}`,
                                children: ty === "0" ? data["paypal-again"] : data["paypal-sent"]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "submit",
                                onClick: handleClose,
                                className: "mt-8 md:mt-12",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `font-proximaNova400 text-base md:text-lg
              leading-[18px] text-gray-100 px-8 md:px-28 py-3
              md:py-[15px] rounded-full
              ${ty === "0" ? "bg-red-500" : "bg-blue-500"}`,
                                    children: ty === "0" ? data["paypal-failed"] : data["paypal-success"]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 6319:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_sections_home_HomeFront__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(988);
/* harmony import */ var _components_sections_home_BottomCTA__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2162);
/* harmony import */ var _components_sections_home_ClubAbout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8678);
/* harmony import */ var _components_sections_home_ClubQuestions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6493);
/* harmony import */ var _components_sections_home_Quote__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3298);
/* harmony import */ var _components_sections_home_UpcomingEvents__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3388);
/* harmony import */ var _components_utils_ThankYouModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2697);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_sections_home_ClubAbout__WEBPACK_IMPORTED_MODULE_6__, _components_sections_home_UpcomingEvents__WEBPACK_IMPORTED_MODULE_9__]);
([_components_sections_home_ClubAbout__WEBPACK_IMPORTED_MODULE_6__, _components_sections_home_UpcomingEvents__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function Home() {
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { data , loading , error  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_12__/* .getTexts */ .r)(locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Home - Ukrainian Association of Moncton"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: data["how-tag-seo"]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                id: "main",
                className: "relativee",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_home_HomeFront__WEBPACK_IMPORTED_MODULE_4__/* .HomeFront */ .G, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_home_ClubQuestions__WEBPACK_IMPORTED_MODULE_7__/* .ClubQuestions */ .R, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg-ukraine bg-cover pb-[5px] ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_home_UpcomingEvents__WEBPACK_IMPORTED_MODULE_9__/* .UpcomingEvents */ .k, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_home_ClubAbout__WEBPACK_IMPORTED_MODULE_6__/* .ClubAbout */ .M, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_home_Quote__WEBPACK_IMPORTED_MODULE_8__/* .Quote */ .p, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_home_BottomCTA__WEBPACK_IMPORTED_MODULE_5__/* .BottomCTA */ .j, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_utils_ThankYouModal__WEBPACK_IMPORTED_MODULE_10__/* .ThankYouModal */ .u, {})
        ]
    });
};
async function getStaticProps(ctx) {
    return {
        props: {
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/index",
                loaderName: "getStaticProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 9354:
/***/ ((module) => {

module.exports = require("fslightbox-react");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [894,27,350,543,52,39,884], () => (__webpack_exec__(6319)));
module.exports = __webpack_exports__;

})();