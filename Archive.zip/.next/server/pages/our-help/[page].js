"use strict";
(() => {
var exports = {};
exports.id = 547;
exports.ids = [547];
exports.modules = {

/***/ 8786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Informative)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3947);
/* harmony import */ var _utils_DonateButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8039);





const Informative = ()=>{
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { data , loading , error  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_3__/* .getTexts */ .r)(locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "flex justify-center mb-[72px] md:mb-14 px-6 md:px-6 xl:px-0",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-center flex-col max-w-[1216px] w-full",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                    className: "text-4xl md:text-[56px] leading-[100%] tracking-wider uppercase text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-proximaNova300",
                            children: data["aboiut-title-light"]
                        }),
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-proximaNova500",
                            children: data["about-title"]
                        }),
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-proximaNova500 text-blue-500",
                            children: data["about-help"]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "pt-12 md:pt-10",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "w-full max-w-[1066px] text-center font-proximaNova300 text-xl md:text-2xl leading-[30px] md:leading-9",
                        children: data["our-help-introduction"]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-end md:justify-center gap-8 pt-16 flex-col md:flex-row items-end md:items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "max-w-[186px] md:max-w-full flex flex-end",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_DonateButton__WEBPACK_IMPORTED_MODULE_4__/* .DonateButton */ .H, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/how",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "font-proximaNova400 text-base md:text-lg leading-[18px] text-blue-500 uppercase flex gap-3 cursor-pointer",
                                    children: [
                                        data["about-volunteer"],
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/blue-right-arrow.svg",
                                            alt: "arrow to the right"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};


/***/ }),

/***/ 8476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "t": () => (/* binding */ MoneyHelpedFront)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/images/our-help/img-d-1.webp
/* harmony default export */ const img_d_1 = ({"src":"/_next/static/media/img-d-1.9669cdb9.webp","height":500,"width":564,"blurDataURL":"data:image/webp;base64,UklGRlQAAABXRUJQVlA4IEgAAADwAQCdASoIAAcAAkA4JagCdGuAAkVgGtAA/snf5XC6udZzIwaZuqt7M8VfE3JgJvPmFv+SafPmFv+Tf3bHA550ZYzo3UUkAAA="});
;// CONCATENATED MODULE: ./assets/images/our-help/img-d-2.webp
/* harmony default export */ const img_d_2 = ({"src":"/_next/static/media/img-d-2.bd0c9368.webp","height":500,"width":564,"blurDataURL":"data:image/webp;base64,UklGRmYAAABXRUJQVlA4IFoAAABwAgCdASoIAAcAAkA4JbACdGuAeTcDA0LFtkgAAM3zvSNpf+XXExnDY42tyyfWyyy7QPG40qMLZiYD6e9NfbXbByfMLezf8mvmmYh/ZtW3tzxiuPzXn02cAAA="});
;// CONCATENATED MODULE: ./assets/images/our-help/img-d-3.webp
/* harmony default export */ const img_d_3 = ({"src":"/_next/static/media/img-d-3.e616f063.webp","height":500,"width":564,"blurDataURL":"data:image/webp;base64,UklGRmAAAABXRUJQVlA4IFQAAAAQAgCdASoIAAcAAkA4JaACdGuAAt0oYg4AAP7GBPuGpLkUu1MuWhILtN/3cKC30B6Gm+kE+/yotf6n13xfUj/BFb/k392xwpIBfiC+l4ix05VggAA="});
;// CONCATENATED MODULE: ./assets/images/our-help/img-m-1.webp
/* harmony default export */ const img_m_1 = ({"src":"/_next/static/media/img-m-1.f41a8472.webp","height":204,"width":121,"blurDataURL":"data:image/webp;base64,UklGRlQAAABXRUJQVlA4IEgAAAAwAgCdASoFAAgAAkA4JbACdEf/geiekhsEAAD+lt21fObezBIJpjK1Qxa/zO/ykqopI93/ykqo/9mQ5cGMorQynn5nUpoAAAA="});
;// CONCATENATED MODULE: ./assets/images/our-help/img-m-2.webp
/* harmony default export */ const img_m_2 = ({"src":"/_next/static/media/img-m-2.b97adf0b.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRloAAABXRUJQVlA4IE4AAABQAgCdASoFAAgAAkA4JbACdGuAeQADA3/yQVAA/mSW5j+ZMWIqflr/zDXIcLyVnA5L7QHiVJN+82fMLcm//l4X+waBEZpu6+Od+aAmAAA="});
;// CONCATENATED MODULE: ./assets/images/our-help/img-m-3.webp
/* harmony default export */ const img_m_3 = ({"src":"/_next/static/media/img-m-3.3290038b.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRlgAAABXRUJQVlA4IEwAAADwAQCdASoFAAgAAkA4JbACdGuAAsz2t5gA/e8CZoN0sFbWbFcbDusQ6RLqb+eO8Knsfyb74O11Tr/U3/92v7ImkXiw4/cZD3fcAAAA"});
;// CONCATENATED MODULE: ./components/sections/moneyhelped/MoneyHelpedFront.jsx








const MoneyHelpedFront = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "flex justify-center items-center mb-[60px]",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between gap-6 flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "hidden tablets:flex justify-between gap-1 tablets:gap-[18px] w-screen about-front-farm",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_d_1,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_d_2,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_d_3,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex tablets:hidden justify-between gap-[5px] w-screen",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_m_1,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_m_2,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_m_3,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 4134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "V": () => (/* binding */ Data)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
;// CONCATENATED MODULE: ./assets/images/divider-line.svg
/* harmony default export */ const divider_line = ({"src":"/_next/static/media/divider-line.89dd9fc0.svg","height":72,"width":2});
;// CONCATENATED MODULE: ./assets/images/divider-line-mobile.svg
/* harmony default export */ const divider_line_mobile = ({"src":"/_next/static/media/divider-line-mobile.a0565ca1.svg","height":1,"width":73});
;// CONCATENATED MODULE: ./components/sections/moneyhelped/data.jsx






const Data = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "flex justify-center mb-[72px] md:mb-14 px-6 md:px-6 xl:px-0 bg-gray-100 md:bg-yellow-500",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col md:flex-row justify-between max-w-[1216px] w-full py-12 items-center gap-10 md:gap-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col md:flex-row items-center gap-2 lg:gap-8 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-3xl md:text-5xl lg:text-[56px] leading-[56px] tracking-wider text-blue-500 md:text-gray-900",
                                        children: data["our-help-families"]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova200 text-xl lg:text-2xl leading-[36px] max-w-[152px] text-center md:text-left",
                                        children: data["our-help-displaced"]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "hidden md:block",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: divider_line,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "block md:hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: divider_line_mobile,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col md:flex-row items-center gap-2 lg:gap-8 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-3xl md:text-5xl lg:text-[56px] leading-[56px] tracking-wider text-blue-500 md:text-gray-900",
                                        children: data["our-help-donation"]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova200 text-xl lg:text-2xl leading-[36px] max-w-[152px] text-center md:text-left",
                                        children: data["our-help-total-money"]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "hidden md:block",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: divider_line,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "block md:hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: divider_line_mobile,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col md:flex-row items-center gap-2 lg:gap-8 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova500 text-3xl md:text-5xl lg:text-[56px] leading-[56px] tracking-wider text-blue-500 md:text-gray-900",
                                        children: data["our-help-fundraiser"]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova200 text-xl lg:text-2xl leading-[36px] max-w-[152px] text-center md:text-left",
                                        children: data["our-help-hospitals"]
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "flex justify-center px-6 pt-8 md:px-6 xl:px-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-col md:flex-row justify-between max-w-[1216px] w-full py-6 items-center gap-10 md:gap-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        className: "font-proximaNova400 text-[32px] md:text-5xl text-left leading-[48px] tracking-wider uppercase",
                        children: data["our-help-help"]
                    })
                })
            })
        ]
    });
};


/***/ }),

/***/ 628:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4030);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3947);
/* harmony import */ var _components_sections_moneyhelped_MoneyHelpedFront__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8476);
/* harmony import */ var _components_sections_moneyhelped_Informative__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8786);
/* harmony import */ var _components_sections_moneyhelped_data__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4134);
/* harmony import */ var _components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7213);
/* harmony import */ var _assets_images_pagination_next_blue_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9818);
/* harmony import */ var _assets_images_pagination_next_gray_svg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9449);
/* harmony import */ var _assets_images_pagination_previous_blue_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4280);
/* harmony import */ var _assets_images_pagination_previous_gray_svg__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4401);
/* harmony import */ var _assets_images_pagination_line_gray_svg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5317);
/* harmony import */ var _services_constants__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(487);
/* harmony import */ var _services_helpers__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7663);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_14__]);
_components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_14__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






















const limit = 6;
function OurHelp({ currentPageNumber , hasNextPage , hasPreviousPage , posts ,  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { data , loading , error  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_10__/* .getTexts */ .r)(router.locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Our help - Ukrainian Association of Moncton"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        // equal data
                        content: data["how-tag-seo"]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                id: "main",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_moneyhelped_MoneyHelpedFront__WEBPACK_IMPORTED_MODULE_11__/* .MoneyHelpedFront */ .t, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "info-section",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "info-section-bg",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_moneyhelped_Informative__WEBPACK_IMPORTED_MODULE_12__/* .Informative */ .z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_moneyhelped_data__WEBPACK_IMPORTED_MODULE_13__/* .Data */ .V, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                                    className: "flex justify-center mb-16 md:mb-28 pl-6 md:px-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex justify-center flex-col max-w-[1215px] w-full",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-between gap-2 xl:gap-0 -ml-[23px] md:ml-0",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_14__/* .MobileSwiperDisplay */ .e, {
                                                        posts: posts
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "justify-start gap-2 xl:gap-8 max-w-full w-full pt-10 hidden md:grid grid-cols-3",
                                                        children: posts.map((post, i)=>{
                                                            return (0,_services_helpers__WEBPACK_IMPORTED_MODULE_20__/* .isPostInvalid */ .Y)(router.locale, post.node) ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "shadow-[0px_2px_22px_rgba(0,32,73,0.13)] w-full max-h-full h-full overflow-hidden bg-gray-100 rounded-3xl mt-6 hidden md:flex flex-col justify-start",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "w-full flex flex-col",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            className: "w-full min-h-[200px] max-h-[200px] md:min-h-[256px] md:max-h-[256px] object-cover",
                                                                            src: post.node.featuredImage.url,
                                                                            alt: router.locale == "ua" ? post.node.localizations[0].title : post.node.title,
                                                                            title: router.locale == "ua" ? post.node.localizations[0].title : post.node.title,
                                                                            loading: "lazy"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "px-4 lg:px-6 pt-6 flex flex-col justify-between h-full",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            className: `font-proximaNova200 text-yellow-900
                              px-6 py-2 rounded-[20px] ${post.node.tags[0]?.name ? "bg-yellow-100" : "bg-none"}`,
                                                                                            children: router.locale == "ua" ? post.node.localizations[0].tags[0]?.name : post.node.tags[0]?.name
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "pt-8",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                                                className: "font-proximaNova500 uppercase text-xl md:text-2xl",
                                                                                                children: router.locale == "ua" ? post.node.localizations[0].title : post.node.title
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                className: "pr-4 md:pr-0 font-proximaNova200 text-base md:text-lg pt-2 leading-[18px]",
                                                                                                children: router.locale == "ua" ? post.node.localizations[0].excerpt : post.node.excerpt
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "w-full md:w-auto flex justify-between items-center pt-10 pb-6",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            className: "font-proximaNova200 text-base text-gray-500 md:text-lg leading-[18px]",
                                                                                            children: moment__WEBPACK_IMPORTED_MODULE_6___default()(post.node.createdAt).format("MMM DD, YYYY")
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                            href: `/posts/${post.node.slug}`,
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "bg-[#006DB6] text-gray-100 py-3 px-8 lg:px-10 rounded-[64px] font-proximaNova400 text-base md:text-lg text-center cursor-pointer",
                                                                                                children: router.locale == "ua" ? "\u0427\u0438\u0442\u0430\u0442\u0438 \u0434\u0430\u043B\u0456" : "Read more"
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }, i);
                                                        })
                                                    })
                                                ]
                                            }),
                                            posts.length > 6 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex justify-center w-full mt-1 md:mt-16 z-50",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex gap-7 border border-gray-500 py-5 px-6 rounded-full",
                                                    children: [
                                                        hasPreviousPage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            href: `${currentPageNumber - 1}`,
                                                            scroll: false,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                    src: _assets_images_pagination_previous_blue_svg__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
                                                                    alt: "previous",
                                                                    className: "cursor-pointer"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            src: _assets_images_pagination_previous_gray_svg__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z,
                                                            alt: ""
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            src: _assets_images_pagination_line_gray_svg__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
                                                            alt: ""
                                                        }),
                                                        hasNextPage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            href: `${currentPageNumber + 1}`,
                                                            scroll: false,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                    src: _assets_images_pagination_next_blue_svg__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
                                                                    alt: "next",
                                                                    className: "cursor-pointer"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            src: _assets_images_pagination_next_gray_svg__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z,
                                                            alt: ""
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
async function getStaticPaths() {
    const query = _apollo_client__WEBPACK_IMPORTED_MODULE_8__.gql`
    {
      postsConnection (where: {category: {slug: "how-your-money-helped" }}) {
        aggregate {
          count
        }
        posts: edges {
          node {
            id
            title
            excerpt
            address
            slug
            createdAt
            tags {
              name
              slug
            }
            featuredImage {
              url
            }
            localizations(locales: uk_UA) {
              title
              excerpt
              tags {
                name
              }
            }
          }
        }
      }
    }
  `;
    const { postsConnection  } = await _services__WEBPACK_IMPORTED_MODULE_9__/* .hygraph.request */ .FN.request(query);
    function* numberOfPages({ total , limit  }) {
        let page = 1;
        let offset = 0;
        while(offset < total){
            yield page;
            page++;
            offset += limit;
        }
    }
    const paths = [
        ...numberOfPages({
            total: postsConnection.aggregate.count,
            limit
        }), 
    ].map((page)=>({
            params: {
                page: String(page)
            }
        }));
    return {
        paths,
        fallback: "blocking"
    };
}
async function _getStaticProps({ params  }) {
    const query = _apollo_client__WEBPACK_IMPORTED_MODULE_8__.gql`
    query postsPageQuery($limit: Int!, $offset: Int!) {
      postsConnection (
        first: $limit,
        skip: $offset,
        where: { category: { slug: "how-your-money-helped" }},
        orderBy: createdAt_DESC
        ) {
        aggregate {
          count
        }
        posts: edges {
          node {
            id
            title
            excerpt
            address
            slug
            createdAt
            tags {
              name
              slug
            }
            featuredImage {
              url
            }
            localizations(locales: uk_UA) {
              title
              excerpt
              tags {
                name
              }
            }
          }
        }
        pageInfo {
          hasNextPage
          hasPreviousPage
        }
      }
    }
  `;
    const { postsConnection: { posts , pageInfo  } ,  } = await _services__WEBPACK_IMPORTED_MODULE_9__/* .hygraph.request */ .FN.request(query, {
        limit,
        offset: Number((params.page - 1) * limit)
    });
    return {
        props: {
            currentPageNumber: Number(params.page),
            posts,
            ...pageInfo
        },
        revalidate: _services_constants__WEBPACK_IMPORTED_MODULE_21__/* .REVALIDATION_TIME_PAGINATION */ .Am
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OurHelp);
async function getStaticProps(ctx) {
    let res = _getStaticProps(ctx);
    if (typeof res.then === "function") res = await res;
    return {
        ...res,
        props: {
            ...res.props || {},
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/our-help/[page]",
                loaderName: "getStaticProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [894,27,350,543,52,30,586,39], () => (__webpack_exec__(628)));
module.exports = __webpack_exports__;

})();