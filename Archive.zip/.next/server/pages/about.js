"use strict";
(() => {
var exports = {};
exports.id = 521;
exports.ids = [521];
exports.modules = {

/***/ 6595:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ About),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./i18n.json
var i18n = __webpack_require__(608);
// EXTERNAL MODULE: external "next-translate/loadNamespaces"
var loadNamespaces_ = __webpack_require__(7462);
var loadNamespaces_default = /*#__PURE__*/__webpack_require__.n(loadNamespaces_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: external "@emailjs/browser"
const browser_namespaceObject = require("@emailjs/browser");
var browser_default = /*#__PURE__*/__webpack_require__.n(browser_namespaceObject);
;// CONCATENATED MODULE: ./assets/images/form/profile.webp
/* harmony default export */ const profile = ({"src":"/_next/static/media/profile.2019e26f.webp","height":24,"width":24,"blurDataURL":"data:image/webp;base64,UklGRogAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAAAAwBm8/l/AAEAKf////9DAABV//f2/3YAAB32////NAABACemrjoAAQB0pJ2foXUBf////////5C1//j7+/n/0gBWUDggIAAAAFABAJ0BKggACAACQDglAE6AKAAA/u8VBgSVqza6YqAA"});
;// CONCATENATED MODULE: ./assets/images/form/email.webp
/* harmony default export */ const email = ({"src":"/_next/static/media/email.d7ab1d11.webp","height":20,"width":24,"blurDataURL":"data:image/webp;base64,UklGRoAAAABXRUJQVlA4WAoAAAAQAAAABwAABgAAQUxQSDkAAAABYFTbtpJm/0dBavw2yJRFHnd3mOkZ0SEiMtybKKr3sFInnKrCFZ4vLWAytRG+C+D6+AV5lmVZHgAAVlA4ICAAAABQAQCdASoIAAcAAkA4JQBOgC6gAP7vFQYElatKcwqAAA=="});
;// CONCATENATED MODULE: ./assets/images/form/phone.webp
/* harmony default export */ const phone = ({"src":"/_next/static/media/phone.4c71c653.webp","height":24,"width":16,"blurDataURL":"data:image/webp;base64,UklGRnAAAABXRUJQVlA4WAoAAAAQAAAABAAABwAAQUxQSCkAAAAA26KlotuXAAAAl5oACQCamQAGAJmaAAgAmpQAAACU5aJ2ouX//6n//wBWUDggIAAAAFABAJ0BKgUACAACQDglAE6AKAAA/u8VBgP/SmGNtwAA"});
;// CONCATENATED MODULE: ./assets/images/form/send.webp
/* harmony default export */ const send = ({"src":"/_next/static/media/send.688cca38.webp","height":18,"width":21,"blurDataURL":"data:image/webp;base64,UklGRngAAABXRUJQVlA4WAoAAAAQAAAABwAABgAAQUxQSDkAAAAAxWIHAAAEAwD//956GwAAAMLY+P/ulS8EABY2Zrf//2DC2Pj/7pUvBP//3nobAAAAxWIHAAAEAwAAVlA4IBgAAAAwAQCdASoIAAcAAkA4JaQAA3AA/vsNAAA="});
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
;// CONCATENATED MODULE: ./components/utils/ContactForm.jsx










const ContactForm = ()=>{
    const form = (0,external_react_.useRef)();
    const { locale  } = (0,router_.useRouter)();
    const { data: dataFrom100 , loadingFrom100 , errorFrom100  } = (0,getTexts/* getTexts */.r)(locale, 100);
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    const { 0: showThankYou , 1: setShowThankYou  } = (0,external_react_.useState)(false);
    const { 0: showError , 1: setShowError  } = (0,external_react_.useState)(false);
    if (loading || loadingFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error || errorFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    const serviceID = "service_bi7i6kv";
    const templateID = "template_u1dy6ag";
    const publicKey = "PWMh_LOWI1YCUQWsk";
    function sendEmail(e) {
        e.preventDefault();
        browser_default().sendForm(serviceID, templateID, form.current, publicKey).then((result)=>{
            console.log(result.text);
            setShowThankYou(true);
            setTimeout(()=>{
                setShowThankYou(false);
            }, 5000);
        }, (error)=>{
            console.log(error.text);
            setShowError(true);
        });
        e.target.reset();
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex tablets:hidden pb-8 justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "font-proximaNova400 uppercase text-[32px] text-center tracking-wider",
                    children: data["about-contact"]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shadow-none tablets:shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 w-full h-full rounded-3xl px-0 tablets:p-16 tablets:pb-10",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        ref: form,
                        onSubmit: sendEmail,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-between gap-0 tablets:gap-16 pb-10 w-full flex-col tablets:flex-row",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "w-full tablets:w-[41.45%] h-full",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col pb-6 tablets:pb-8",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "font-proximaNova400 text-sm pb-4",
                                                        htmlFor: "name",
                                                        children: data["about-name"]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "bg-gray-200 px-4 flex items-center gap-8 rounded-2xl",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: profile,
                                                                alt: "profile"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                className: "text-base tablets:text-lg font-proximaNova300 bg-gray-200 py-3 tablets:py-[19px] w-full text-gray-900 placeholder:text-gray-500",
                                                                name: "name",
                                                                id: "name",
                                                                type: "name",
                                                                placeholder: dataFrom100["placeholder-name"],
                                                                required: true
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col pb-6 tablets:pb-8",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "font-proximaNova400 text-sm pb-4",
                                                        htmlFor: "email",
                                                        children: dataFrom100["form-email"]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "bg-gray-200 px-4 flex items-center gap-8 rounded-2xl",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: email,
                                                                alt: "email"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                className: "text-base tablets:text-lg font-proximaNova300 bg-gray-200 w-full py-3 tablets:py-[19px] text-gray-900 placeholder:text-gray-500",
                                                                name: "email",
                                                                id: "email",
                                                                type: "email",
                                                                placeholder: dataFrom100["placeholder-email"],
                                                                required: true
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "font-proximaNova400 text-sm pb-4",
                                                        htmlFor: "phone",
                                                        children: dataFrom100["form-phone"]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "bg-gray-200 px-4 flex items-center gap-10 rounded-2xl",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: phone,
                                                                alt: "phone"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                className: "text-base tablets:text-lg font-proximaNova300] text-gray-900 bg-gray-200 w-full py-3 tablets:py-[19px] placeholder:text-gray-500",
                                                                name: "phone",
                                                                id: "phone",
                                                                type: "phone",
                                                                placeholder: dataFrom100["placeholder-phone"]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "w-full tablets:w-[58.55%] pt-6 tablets:pt-0",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                className: "font-proximaNova400 text-sm",
                                                htmlFor: "message",
                                                children: data["about-message"]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                className: "bg-gray-200 px-6 py-3 tablets:py-6 flex items-center gap-10 rounded-2xl resize-none w-full h-32 tablets:h-[90%] mt-[15px] text-base tablets:text-lg placeholder:text-gray-500 text-gray-900",
                                                name: "message",
                                                id: "message",
                                                placeholder: data["about-feed-animals"],
                                                minLength: 20,
                                                required: true
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex justify-center items-center",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    className: "bg-blue-500 text-gray-100 py-[15px] px-8 rounded-[50px] flex items-center gap-[18px] justify-between",
                                    type: "submit",
                                    children: [
                                        data["about-field"],
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: send,
                                            alt: "send"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pt-6 flex justify-center w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: `${showThankYou ? "visible text-blue-500" : "invisible"}`,
                                children: data["about-thank-message"]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: `${showError ? "inline-block visible text-yellow-500" : "invisible hidden"}`,
                                children: data["about-errror"]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./assets/images/contacts/email.svg
/* harmony default export */ const contacts_email = ({"src":"/_next/static/media/email.3efc0db2.svg","height":26,"width":32});
;// CONCATENATED MODULE: ./assets/images/contacts/email-active.svg
/* harmony default export */ const email_active = ({"src":"/_next/static/media/email-active.0fa51cf6.svg","height":26,"width":32});
;// CONCATENATED MODULE: ./assets/images/contacts/facebook-active.svg
/* harmony default export */ const facebook_active = ({"src":"/_next/static/media/facebook-active.678b5810.svg","height":27,"width":28});
;// CONCATENATED MODULE: ./assets/images/contacts/facebook.svg
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.2940ff73.svg","height":28,"width":28});
;// CONCATENATED MODULE: ./assets/images/contacts/instagram.svg
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.64ca6611.svg","height":28,"width":28});
;// CONCATENATED MODULE: ./assets/images/contacts/instagram-active.svg
/* harmony default export */ const instagram_active = ({"src":"/_next/static/media/instagram-active.f18a0e4a.svg","height":28,"width":28});
;// CONCATENATED MODULE: ./components/sections/about/Contacts.jsx












const Contacts = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data: dataFrom100 , loading: loadingFrom100 , error: errorFrom100  } = (0,getTexts/* getTexts */.r)(locale, 100);
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    const { 0: instagramActive , 1: setInstagramActive  } = (0,external_react_.useState)(false);
    const { 0: facebookActive , 1: setFacebookActive  } = (0,external_react_.useState)(false);
    const { 0: emailActive , 1: setEmailActive  } = (0,external_react_.useState)(false);
    if (loading || loadingFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error || errorFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    const toggleFacebookStyle = ()=>{
        setFacebookActive(!facebookActive);
        setInstagramActive(false);
        setEmailActive(false);
    };
    const toggleEmailStyle = ()=>{
        setEmailActive(!emailActive);
        setInstagramActive(false);
        setFacebookActive(false);
    };
    const toggleInstagramStyle = ()=>{
        setInstagramActive(!instagramActive);
        setFacebookActive(false);
        setEmailActive(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "flex justify-center w-full mb-[72px] md:mb-24 px-6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between flex-col max-w-[1216px] w-full",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "font-proximaNova400 text-[40px] leading-[100%] tracking-wider uppercase text-center",
                    children: data["about-our-contacts"]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex gap-5 justify-between w-full pt-11 mb-[72px] md:mb-10 flex-col lg:flex-row",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: instagramActive && dataFrom100["instagram-navigation"],
                            rel: "noreferrer",
                            target: "_blank",
                            className: `shadow-[0px_2px_32px_rgba(0,32,73,0.13)] rounded-3xl 
          flex flex-col  items-center justify-center w-full py-[25px] cursor-pointer
          transition-all
          ${instagramActive ? "bg-blue-500" : "bg-gray-100"}`,
                            onClick: toggleInstagramStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: instagramActive ? instagram_active : instagram,
                                    alt: "isntagram"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `font-proximaNova500 text-base md:text-lg leading-[150%]  mt-[4px]
              ${instagramActive ? "text-gray-100" : "text-blue-500"}`,
                                    children: data["instagram-description"]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: facebookActive && data["facebook-navigation"],
                            rel: "noreferrer",
                            target: "_blank",
                            className: `shadow-[0px_2px_32px_rgba(0,32,73,0.13)] rounded-3xl 
          flex flex-col  items-center justify-center w-full py-[25px] cursor-pointer
          transition-all 
          ${facebookActive ? "bg-blue-500" : "bg-gray-100"}`,
                            onClick: toggleFacebookStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: facebookActive ? facebook : facebook_active,
                                    alt: "facebook"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `font-proximaNova500 text-base md:text-lg leading-[150%]  mt-[4px]
              ${facebookActive ? "text-gray-100" : "text-blue-500"}`,
                                    children: data["facebook-description"]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            rel: "noreferrer",
                            target: "_blank",
                            href: emailActive && `mailto:${data["about-email-box"]}`,
                            className: `shadow-[0px_2px_32px_rgba(0,32,73,0.13)] rounded-3xl 
          flex flex-col  items-center justify-center w-full py-[25px] cursor-pointer
          transition-all
          ${emailActive ? "bg-blue-500" : "bg-gray-100"}`,
                            onClick: toggleEmailStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: emailActive ? email_active : contacts_email,
                                    alt: "email",
                                    width: 32,
                                    height: 24.9
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `font-proximaNova500 text-base md:text-lg leading-[150%] mt-[4px]
              max-w-[205px] inline-block
              ${emailActive ? "text-gray-100" : "text-blue-500"}`,
                                    children: data["about-email-box"]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ContactForm, {})
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/sections/about/Informative.jsx



const Informative = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "flex justify-center mb-[72px] md:mb-24 px-6 md:px-6 xl:px-0",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-center flex-col max-w-[1216px] w-full",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "font-proximaNova500 text-4xl md:text-[56px] leading-[100%] tracking-wider uppercase text-left md:text-center",
                    children: data["about-title-we-are"]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "pt-8 md:pt-11",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "w-full md:w-[98%] text-left md:text-center font-proximaNova300 text-xl md:text-2xl leading-9",
                        children: data["about-paragraph"]
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./assets/images/about/farm-d-01.webp
/* harmony default export */ const farm_d_01 = ({"src":"/_next/static/media/farm-d-01.23968172.webp","height":504,"width":564,"blurDataURL":"data:image/webp;base64,UklGRlYAAABXRUJQVlA4IEoAAADwAQCdASoIAAcAAkA4JYgCdAEfhlkgjQAA/vZehnTYUVQA31GrgCmD2gxx2ga3u1Z6UkTSOBr4O453Iko4CS2J24t4upd9c3gAAA=="});
;// CONCATENATED MODULE: ./assets/images/about/farm-d-02.webp
/* harmony default export */ const farm_d_02 = ({"src":"/_next/static/media/farm-d-02.d03447b2.webp","height":504,"width":564,"blurDataURL":"data:image/webp;base64,UklGRloAAABXRUJQVlA4IE4AAADwAQCdASoIAAcAAkA4JagCdAEfbIi8zAAA/vQXIBw548aWLkTe/PIncJkB5oZF3T4bUm8xu25nUep1XF4qKS76/i1U6QJ4BrxmtoAAAAA="});
;// CONCATENATED MODULE: ./assets/images/about/farm-d-03.webp
/* harmony default export */ const farm_d_03 = ({"src":"/_next/static/media/farm-d-03.27c5f13f.webp","height":504,"width":564,"blurDataURL":"data:image/webp;base64,UklGRlYAAABXRUJQVlA4IEoAAADwAQCdASoIAAcAAkA4JaACdAEfbQZECYAA/vQF9QeFvYLShFT9IvHXC887btP50WfgSaEpVdJxNyZ83xenuH6/59eAeVDrRUAAAA=="});
;// CONCATENATED MODULE: ./assets/images/about/farm-m-01.webp
/* harmony default export */ const farm_m_01 = ({"src":"/_next/static/media/farm-m-01.e30cc489.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRlAAAABXRUJQVlA4IEQAAADwAQCdASoFAAgAAkA4JbACdAEUoJSXEAAA/vCvwt9XSN6bavMIdd3h6nV+YPdCudbHDq7eERkD+NzVOMhV8M12wpgAAA=="});
;// CONCATENATED MODULE: ./assets/images/about/farm-m-02.webp
/* harmony default export */ const farm_m_02 = ({"src":"/_next/static/media/farm-m-02.c8d39384.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRlIAAABXRUJQVlA4IEYAAAAQAgCdASoFAAgAAkA4JbACdEf/gegDnhaAAP760zCllKHvp9OoxKhbNM+Viq9ZaXsv/KSqj/ezpSXXnRaBndms3sKgAAAA"});
;// CONCATENATED MODULE: ./assets/images/about/farm-m-03.webp
/* harmony default export */ const farm_m_03 = ({"src":"/_next/static/media/farm-m-03.f0731f59.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRlgAAABXRUJQVlA4IEwAAADwAQCdASoFAAgAAkA4JbACdEf/gegCtqAA/vVRoOshGIDajhcVdard3Qgq5Q/8qK3k7To/+0l/g3/97yY/4nXysuNZ86WZ/QMk4AAA"});
;// CONCATENATED MODULE: ./components/sections/about/AboutFront.jsx








const AboutFront = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "flex justify-center items-center mb-[60px]",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between gap-6 flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "hidden tablets:flex justify-between gap-1 tablets:gap-[18px] w-screen about-front-farm",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: farm_d_01,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: farm_d_02,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: farm_d_03,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex tablets:hidden justify-between gap-[5px] w-screen",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: farm_m_01,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: farm_m_02,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: farm_m_03,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./pages/about.jsx









function About() {
    const router = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(router.locale);
    const { data: dataFrom100 , loading: loadingFrom100 , error: errorFrom100  } = (0,getTexts/* getTexts */.r)(router.locale, 100);
    if (loading || loadingFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error || errorFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            "About - ",
                            dataFrom100["assosiation-of-moncton"]
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: data["about-description-seo"]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AboutFront, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                id: "main",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "about-section",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "about-section-bg",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Informative, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(Contacts, {})
                        ]
                    })
                })
            })
        ]
    });
};
async function getStaticProps(ctx) {
    return {
        props: {
            ...await loadNamespaces_default()({
                ...ctx,
                pathname: "/about",
                loaderName: "getStaticProps",
                ...i18n,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [894,27,52], () => (__webpack_exec__(6595)));
module.exports = __webpack_exports__;

})();