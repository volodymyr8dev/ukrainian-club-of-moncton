"use strict";
(() => {
var exports = {};
exports.id = 576;
exports.ids = [576];
exports.modules = {

/***/ 7732:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ukrainian-symbol.da245e3f.svg","height":183,"width":556});

/***/ }),

/***/ 3155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "r": () => (/* binding */ InfoFront)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/images/info/img-d-1.webp
/* harmony default export */ const img_d_1 = ({"src":"/_next/static/media/img-d-1.8d6771a4.webp","height":504,"width":564,"blurDataURL":"data:image/webp;base64,UklGRlgAAABXRUJQVlA4IEwAAAAQAgCdASoIAAcAAkA4JagCdH8AFclu+eg0AP7wtKND2wvbafl9Cy+8yQ1QA5LMW7uA+eGoZ6BFJa/LUZdsdm+UdRNbC6maUkruAAAA"});
;// CONCATENATED MODULE: ./assets/images/info/img-d-2.webp
/* harmony default export */ const img_d_2 = ({"src":"/_next/static/media/img-d-2.e027332d.webp","height":504,"width":564,"blurDataURL":"data:image/webp;base64,UklGRlAAAABXRUJQVlA4IEQAAADQAQCdASoIAAcAAkA4JQBOgB6UJzyDgAD+9nff9yzgfdh1Zbi2shibjZB0/6aZnhCcEHbCewaIn5J9b2XzNikvOnRAAA=="});
;// CONCATENATED MODULE: ./assets/images/info/img-d-3.webp
/* harmony default export */ const img_d_3 = ({"src":"/_next/static/media/img-d-3.f1d77e69.webp","height":504,"width":564,"blurDataURL":"data:image/webp;base64,UklGRlgAAABXRUJQVlA4IEwAAAAwAgCdASoIAAcAAkA4JbACdGuAAvp8+XVpAAD+91Z9zojkHKnPbqHAXD2HhdnOC+86b4WjqPbmMZJqE/3hB0xD+yY3WuvsgjkYAAAA"});
;// CONCATENATED MODULE: ./assets/images/info/img-m-1.webp
/* harmony default export */ const img_m_1 = ({"src":"/_next/static/media/img-m-1.b0a0a1d6.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRlgAAABXRUJQVlA4IEwAAADQAQCdASoFAAgAAkA4JbACdAEPBF6aQAD++a2G7hml55VyS6FpOc1hZm2aEv14i1U/l9gZRqm57/U43X9hDi7tP+69f8UsFDf1ooAA"});
;// CONCATENATED MODULE: ./assets/images/info/img-m-2.webp
/* harmony default export */ const img_m_2 = ({"src":"/_next/static/media/img-m-2.31d9e228.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRlAAAABXRUJQVlA4IEQAAAAwAgCdASoFAAgAAkA4JaACdGuAt/8D0ARRoAD+67GHC68jkqxvrO7qF+p55iRXNbpEQwFSx0+wi5G372ro1cTM+hHQAA=="});
;// CONCATENATED MODULE: ./assets/images/info/img-m-3.webp
/* harmony default export */ const img_m_3 = ({"src":"/_next/static/media/img-m-3.1c7400c1.webp","height":204,"width":122,"blurDataURL":"data:image/webp;base64,UklGRkoAAABXRUJQVlA4ID4AAADwAQCdASoFAAgAAkA4JbACdGuAAs2rz/AA/vVPgZhGwq/aF9fclfxA+i/5NYuP/k3/7BdjcKwixt933AAAAA=="});
;// CONCATENATED MODULE: ./components/sections/info/InfoFront.jsx








const InfoFront = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "flex justify-center items-center mb-[60px]",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between gap-6 flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "hidden tablets:flex justify-between gap-1 tablets:gap-[18px] w-screen about-front-farm",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_d_1,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_d_2,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_d_3,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex tablets:hidden justify-between gap-[5px] w-screen",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_m_1,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_m_2,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: img_m_3,
                                    alt: "farm",
                                    layout: "responsive",
                                    priority: true
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 5465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Informative)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3947);
/* harmony import */ var _assets_images_ukrainian_symbol_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7732);





const Informative = ()=>{
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { data , loading , error  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_3__/* .getTexts */ .r)(locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "flex justify-center mb-[72px] md:mb-24 px-6 md:px-6 xl:px-0",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-center flex-col max-w-[1216px] w-full",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "font-proximaNova500 text-4xl md:text-[56px] leading-[100%] tracking-wider uppercase text-center",
                    children: data["info-info-center"]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center pt-10",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: _assets_images_ukrainian_symbol_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                        layout: "intrinsic",
                        alt: "",
                        priority: true
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "pt-8 md:pt-11",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "w-full md:w-[98%] text-center font-proximaNova300 text-xl md:text-2xl leading-[30px] md:leading-9",
                        children: [
                            data["info-introduction-1"],
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                className: "block md:hidden"
                            }),
                            data["info-introduction"]
                        ]
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 3557:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services_getTexts_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3947);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4030);
/* harmony import */ var _components_sections_info_InfoFront__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3155);
/* harmony import */ var _components_sections_info_Informative__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5465);
/* harmony import */ var _components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7213);
/* harmony import */ var _assets_images_pagination_next_blue_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9818);
/* harmony import */ var _assets_images_pagination_next_gray_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9449);
/* harmony import */ var _assets_images_pagination_previous_blue_svg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4280);
/* harmony import */ var _assets_images_pagination_previous_gray_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4401);
/* harmony import */ var _assets_images_pagination_line_gray_svg__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5317);
/* harmony import */ var _services_constants__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(487);
/* harmony import */ var _services_helpers__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7663);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_13__]);
_components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_13__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/* file name: [page].jsx */ 





















const limit = 6;
function PostPage({ currentPageNumber , hasNextPage , hasPreviousPage , posts ,  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { data , loading , error  } = (0,_services_getTexts_js__WEBPACK_IMPORTED_MODULE_9__/* .getTexts */ .r)(router.locale);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Info - Ukrainian Association of Moncton"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        // equal data
                        content: data["how-tag-seo"]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                id: "main",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_info_InfoFront__WEBPACK_IMPORTED_MODULE_11__/* .InfoFront */ .r, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "info-section",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "info-section-bg",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sections_info_Informative__WEBPACK_IMPORTED_MODULE_12__/* .Informative */ .z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                                    className: "flex justify-center mb-16 md:mb-28 pl-6 md:px-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex justify-center flex-col max-w-[1215px] w-full",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-between gap-2 xl:gap-0 -ml-[23px] md:ml-0",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_utils_MobileSwiperDisplay__WEBPACK_IMPORTED_MODULE_13__/* .MobileSwiperDisplay */ .e, {
                                                        posts: posts
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "justify-start gap-2 xl:gap-8 max-w-full w-full pt-10 hidden md:grid grid-cols-3",
                                                        children: posts.map((post, i)=>{
                                                            return (0,_services_helpers__WEBPACK_IMPORTED_MODULE_19__/* .isPostInvalid */ .Y)(router.locale, post.node) ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "shadow-[0px_2px_22px_rgba(0,32,73,0.13)] w-full max-h-full h-full overflow-hidden bg-gray-100 rounded-3xl mt-6 hidden md:flex flex-col justify-start",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "w-full flex flex-col",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                            className: "w-full min-h-[200px] max-h-[200px] md:min-h-[256px] md:max-h-[256px] object-cover",
                                                                            src: post.node.featuredImage.url,
                                                                            alt: router.locale == "ua" ? post.node.localizations[0].title : post.node.title,
                                                                            title: router.locale == "ua" ? post.node.localizations[0].title : post.node.title,
                                                                            loading: "lazy"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "px-4 lg:px-6 pt-6 flex flex-col justify-between h-full",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            className: `font-proximaNova200 text-yellow-900
                              px-6 py-2 rounded-[20px] ${post.node.tags[0]?.name ? "bg-yellow-100" : "bg-none"}`,
                                                                                            children: router.locale == "ua" ? post.node.localizations[0].tags[0]?.name : post.node.tags[0]?.name
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "pt-8",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                                                className: "font-proximaNova500 uppercase text-xl md:text-2xl",
                                                                                                children: router.locale == "ua" ? post.node.localizations[0].title : post.node.title
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                className: "pr-4 md:pr-0 font-proximaNova200 text-base md:text-lg pt-2 leading-[18px]",
                                                                                                children: router.locale == "ua" ? post.node.localizations[0].excerpt : post.node.excerpt
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "w-full md:w-auto flex justify-between items-center pt-10 pb-6",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            className: "font-proximaNova200 text-base text-gray-500 md:text-lg leading-[18px]",
                                                                                            children: moment__WEBPACK_IMPORTED_MODULE_6___default()(post.node.createdAt).format("MMM DD, YYYY")
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                            href: `/posts/${post.node.slug}`,
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "bg-[#006DB6] text-gray-100 py-3 px-8 lg:px-10 rounded-[64px] font-proximaNova400 text-base md:text-lg text-center cursor-pointer",
                                                                                                children: router.locale == "ua" ? "\u0427\u0438\u0442\u0430\u0442\u0438 \u0434\u0430\u043B\u0456" : "Read more"
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }, i);
                                                        })
                                                    })
                                                ]
                                            }),
                                            posts.length > 6 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex justify-center w-full mt-1 md:mt-16 z-50",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex gap-7 border border-gray-500 py-5 px-6 rounded-full",
                                                    children: [
                                                        hasPreviousPage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            href: `${currentPageNumber - 1}`,
                                                            scroll: false,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                    src: _assets_images_pagination_previous_blue_svg__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z,
                                                                    alt: "previous",
                                                                    className: "cursor-pointer"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            src: _assets_images_pagination_previous_gray_svg__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
                                                            alt: ""
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            src: _assets_images_pagination_line_gray_svg__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z,
                                                            alt: ""
                                                        }),
                                                        hasNextPage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            href: `${currentPageNumber + 1}`,
                                                            scroll: false,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                    src: _assets_images_pagination_next_blue_svg__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
                                                                    alt: "next",
                                                                    className: "cursor-pointer"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            src: _assets_images_pagination_next_gray_svg__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
                                                            alt: ""
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
async function getStaticPaths() {
    const query = _apollo_client__WEBPACK_IMPORTED_MODULE_8__.gql`
    {
      postsConnection (where: {category: {slug: "going-to-canada" }}) {
        aggregate {
          count
        }
        posts: edges {
          node {
            id
            title
            excerpt
            address
            slug
            createdAt
            tags {
              name
              slug
            }
            featuredImage {
              url
            }
            localizations(locales: uk_UA) {
              title
              excerpt
              tags {
                name
              }
            }
          }
        }
      }
    }
  `;
    const { postsConnection  } = await _services__WEBPACK_IMPORTED_MODULE_10__/* .hygraph.request */ .FN.request(query);
    function* numberOfPages({ total , limit  }) {
        let page = 1;
        let offset = 0;
        while(offset < total){
            yield page;
            page++;
            offset += limit;
        }
    }
    const paths = [
        ...numberOfPages({
            total: postsConnection.aggregate.count,
            limit
        }), 
    ].map((page)=>({
            params: {
                page: String(page)
            }
        }));
    return {
        paths,
        fallback: "blocking"
    };
}
async function _getStaticProps({ params  }) {
    const query = _apollo_client__WEBPACK_IMPORTED_MODULE_8__.gql`
    query postsPageQuery($limit: Int!, $offset: Int!) {
      postsConnection (
        first: $limit,
        skip: $offset,
        where: { category: { slug: "going-to-canada" }},
        orderBy: createdAt_DESC
        ) {
        aggregate {
          count
        }
        posts: edges {
          node {
            id
            title
            excerpt
            address
            slug
            createdAt
            tags {
              name
              slug
            }
            featuredImage {
              url
            }
            localizations(locales: uk_UA) {
              title
              excerpt
              tags {
                name
              }
            }
          }
        }
        pageInfo {
          hasNextPage
          hasPreviousPage
        }
      }
    }
  `;
    const { postsConnection: { posts , pageInfo  } ,  } = await _services__WEBPACK_IMPORTED_MODULE_10__/* .hygraph.request */ .FN.request(query, {
        limit,
        offset: Number((params.page - 1) * limit)
    });
    return {
        props: {
            currentPageNumber: Number(params.page),
            posts,
            ...pageInfo
        },
        revalidate: _services_constants__WEBPACK_IMPORTED_MODULE_20__/* .REVALIDATION_TIME_PAGINATION */ .Am
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PostPage);
async function getStaticProps(ctx) {
    let res = _getStaticProps(ctx);
    if (typeof res.then === "function") res = await res;
    return {
        ...res,
        props: {
            ...res.props || {},
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/info/[page]",
                loaderName: "getStaticProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [894,27,350,543,52,30,586], () => (__webpack_exec__(3557)));
module.exports = __webpack_exports__;

})();