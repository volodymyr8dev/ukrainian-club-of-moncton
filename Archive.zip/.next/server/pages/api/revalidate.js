"use strict";
(() => {
var exports = {};
exports.id = 500;
exports.ids = [500];
exports.modules = {

/***/ 3875:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/revalidate.js

async function handler(request, response) {
    if (request.query.secret !== process.env.REVALIDATE_TOKEN) {
        return response.status(401).json({
            message: "Invalid token"
        });
    }
    if (!request.body) {
        return response.status(422).json({
            message: "Invalid requestuest body"
        });
    }
    try {
        await response.revalidate(external_path_default().join("/", request.body.data.page));
        return response.status(200).json({
            revalidated: true
        });
    } catch (err) {
        return response.status(500).send("Error revalidating");
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3875));
module.exports = __webpack_exports__;

})();