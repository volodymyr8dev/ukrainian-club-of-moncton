"use strict";
(() => {
var exports = {};
exports.id = 922;
exports.ids = [922];
exports.modules = {

/***/ 8745:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/card-location.1aad0a86.svg","height":24,"width":19});

/***/ }),

/***/ 4323:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/UKR_Logo.277f4a0e.png","height":181,"width":194,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAyUlEQVR42mOAgL2MIDLn+JfQoku/fBjO/ucG8VdevsgEkX/+n8l868sZHWcf/1t85dr/h9eLp/y/zgBSBAFmfReV5eff/zTl2LH/R64t+v/tqcTvt09j5OAKum9942DIP7ynftHW/09e9v//8dZh94t75sIMICBeexhqzy7RF497i/7/TSv4/59BFiTy4HY2C0Qud5sib+EOfYbkHXoMDCe1GJz2GnnUbFBjgIPcrZqMudvsePO2+liVb3YzKNnsypC9TZ+BgYEBABpYVSZcJs7LAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 5449:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/twitter.5e556a27.svg","height":64,"width":64});

/***/ }),

/***/ 634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Vector.e97e3031.webp","height":24,"width":20,"blurDataURL":"data:image/webp;base64,UklGRoYAAABXRUJQVlA4WAoAAAAQAAAABgAABwAAQUxQSDkAAAAAAHu8hK+mAHOtgJaL3JiiAABt/mOVi0R9fHWKhI1Ff3FDgoeLUZeMVoOTkyFDOijDcpWPeXafcwAAVlA4ICYAAACQAQCdASoHAAgAAkA4JZACdLoAA5gA/vlnH+KC4KS1Lw5YaAEAAA=="});

/***/ }),

/***/ 8981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Vector_active.809090ef.webp","height":24,"width":20,"blurDataURL":"data:image/webp;base64,UklGRoQAAABXRUJQVlA4WAoAAAAQAAAABgAABwAAQUxQSDkAAAAAAHu8hK+mAHOtgJaL3JiiAABt/mOVi0R9fHWKhI1Ff3FDgoeLUZeMVoOTkyFDOijDcpWPeXafcwAAVlA4ICQAAABQAQCdASoHAAgAAkA4JaAABDOAAP7t7Wf/+YJ/7/f9/vJcAAA="});

/***/ }),

/***/ 6788:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/facebook.7f4a0117.svg","height":20,"width":20});

/***/ }),

/***/ 9024:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/yellow-check.24178d3a.svg","height":16,"width":19});

/***/ }),

/***/ 9596:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PostDetail)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7229);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5371);
/* harmony import */ var _mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_share__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8797);
/* harmony import */ var next_share__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_share__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _RelatedPosts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1765);
/* harmony import */ var _assets_images_post_UKR_Logo_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4323);
/* harmony import */ var _assets_images_slug_facebook_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6788);
/* harmony import */ var _assets_images_post_twitter_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5449);
/* harmony import */ var _assets_images_yellow_check_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9024);
/* harmony import */ var _assets_images_slug_Vector_webp__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(634);
/* harmony import */ var _assets_images_slug_Vector_active_webp__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8981);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _services_getTexts__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_RelatedPosts__WEBPACK_IMPORTED_MODULE_9__]);
_RelatedPosts__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


















const PostDetail = ({ post  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_16__.useRouter)();
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [copied, setCopied] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const { data: dataFrom100 , loading: loadingFrom100 , error: errorFrom100  } = (0,_services_getTexts__WEBPACK_IMPORTED_MODULE_17__/* .getTexts */ .r)(router.locale, 100);
    const { data , loading , error  } = (0,_services_getTexts__WEBPACK_IMPORTED_MODULE_17__/* .getTexts */ .r)(router.locale);
    if (loading || loadingFrom100) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    if (error || errorFrom100) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
    const handleTooltipClose = ()=>setOpen(false);
    const handleTooltipOpen = ()=>{
        setOpen(true);
        setTimeout(()=>{
            setOpen(false);
        }, "5000");
    };
    const HtmlTooltip = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__.styled)(({ className , ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_5___default()), {
            ...props,
            classes: {
                popper: className
            }
        }))(({ theme  })=>({
            [`& .${_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_5__.tooltipClasses.tooltip}`]: {
                backgroundColor: "rgba(255, 255, 255, 0)"
            }
        }));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "flex justify-center mb-[72px] md:mb-24 px-6 md:px-6 xl:px-0 pt-3 md:pt-16",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-center flex-col max-w-[1216px] w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "hidden md:flex justify-center w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: _assets_images_post_UKR_Logo_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                            alt: "",
                            width: 89,
                            height: 84,
                            priority: true
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "pt-8",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "font-proximaNova400 md:font-proximaNova500 text-[32px] md:text-[56px] tracking-wider uppercase text-left md:text-center",
                                children: router.locale == "ua" ? post.localizations[0].title : post.title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col items-center justify-center w-full pt-6 md:pt-0",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-proximaNova200 text-gray-500 uppercase text-base md:text-lg leading-[18px] text-left md:text-center w-full",
                                        children: router.locale == "ua" ? post.localizations[0].tags[0]?.name : post.tags[0]?.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "inline-block md:hidden font-proximaNova200 text-gray-500 uppercase text-base md:text-lg leading-[18px] text-left md:text-center w-full",
                                        children: moment__WEBPACK_IMPORTED_MODULE_3___default()(post.createdAt).format("MMMM DD, YYYY")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-8 md:pt-16",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    className: "min-w-full",
                                    src: post.featuredImage.url,
                                    alt: router.locale == "ua" ? post.localizations[0].title : post.title
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "absolute hidden small-notebooks:flex flex-col justify-start",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mt-16 pt-4 font-proximaNova400 text-4xl leading-8 text-center tracking-wider px-2 border-blue-500 border-t-4",
                                        children: moment__WEBPACK_IMPORTED_MODULE_3___default()(post.createdAt).format("DD")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-proximaNova300 text-sm text-center",
                                        children: moment__WEBPACK_IMPORTED_MODULE_3___default()(post.createdAt).format("MMM, YY")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "hidden small-notebooks:flex flex-col gap-4 pt-8 overflow-visible",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] h-16 w-16 flex justify-center items-center pt-1 rounded-full cursor-pointer",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_share__WEBPACK_IMPORTED_MODULE_8__.FacebookShareButton, {
                                                    url: data["facebook-navigation"],
                                                    quote: dataFrom100["post-assosiation-of-moncton"],
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        src: _assets_images_slug_facebook_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
                                                        alt: "facebook",
                                                        width: 26,
                                                        height: 26
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] h-16 w-16 rounded-full cursor-pointer",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_share__WEBPACK_IMPORTED_MODULE_8__.TwitterShareButton, {
                                                    url: `${baseURL}${router.asPath}`,
                                                    quote: dataFrom100["post-assosiation-of-moncton"],
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        src: _assets_images_post_twitter_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
                                                        alt: "twitter",
                                                        width: 64,
                                                        height: 64
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] h-16 w-16 rounded-full cursor-pointer",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    onClick: ()=>{
                                                        setCopied(true);
                                                        navigator.clipboard.writeText(`${baseURL}${router.asPath}`);
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "overflow-visible",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                            onClickAway: handleTooltipClose,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HtmlTooltip, {
                                                                PopperProps: {
                                                                    disablePortal: true
                                                                },
                                                                placement: "top-start",
                                                                leaveTouchDelay: 2000,
                                                                onClose: handleTooltipClose,
                                                                open: open,
                                                                disableFocusListener: true,
                                                                disableHoverListener: true,
                                                                disableTouchListener: true,
                                                                arrow: true,
                                                                title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex justify-center items-center gap-3 bg-gray-900 p-4 rounded-lg",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "flex justify-center",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                                    src: _assets_images_yellow_check_svg__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
                                                                                    width: 15.7,
                                                                                    height: 12
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                                sx: {
                                                                                    color: "#FFF",
                                                                                    bgcolor: "#002049",
                                                                                    fontWeight: "light"
                                                                                },
                                                                                children: router.locale == "en" ? "Copied to clipboard" : "\u0421\u043A\u043E\u043F\u0456\u0439\u043E\u0432\u0430\u043D\u043E \u0432 \u0431\u0443\u0444\u0435\u0440 \u043E\u0431\u043C\u0456\u043D\u0443"
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "h-16 w-16 flex items-center justify-center",
                                                                    onClick: handleTooltipOpen,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                        src: copied ? _assets_images_slug_Vector_active_webp__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z : _assets_images_slug_Vector_webp__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
                                                                        alt: "copy to clipboard",
                                                                        title: "copy to clipboard",
                                                                        width: 18.86,
                                                                        height: 24
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full min-w-full max-w-[960px] flex justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full max-w-[960px] custom-post-page-styles",
                                    dangerouslySetInnerHTML: {
                                        __html: router.locale == "ua" ? post.localizations[0].content.html : post.content.html
                                    }
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "min-w-full max-w-[960px] flex flex-col justify-center items-center",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "font-proximaNova300 text-2xl leading-[36px] w-full max-w-[960px] text-left",
                                        children: [
                                            router.locale === "en" ? "TAGS:" : "\u041C\u0406\u0422\u041A\u0418:",
                                            " ",
                                            post.tags.length < 1 ? post.tags.map((tag)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "uppercase text-blue-500",
                                                    children: [
                                                        tag.name,
                                                        ", "
                                                    ]
                                                }, tag.name)) : post.tags.map((tag)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "uppercase text-blue-500",
                                                    children: tag.name
                                                }, tag.name))
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-4 pt-8 w-full max-w-[960px]",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] h-16 w-16 rounded-full cursor-pointer flex items-center justify-center pt-[2px]",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_share__WEBPACK_IMPORTED_MODULE_8__.FacebookShareButton, {
                                                    url: `${baseURL}${router.asPath}`,
                                                    quote: dataFrom100["post-assosiation-of-moncton"],
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        src: _assets_images_slug_facebook_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
                                                        alt: "facebook"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] h-16 w-16 rounded-full cursor-pointer",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_share__WEBPACK_IMPORTED_MODULE_8__.TwitterShareButton, {
                                                    url: `${baseURL}${router.asPath}`,
                                                    quote: dataFrom100["post-assosiation-of-moncton"],
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        src: _assets_images_post_twitter_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
                                                        alt: "twitter",
                                                        width: 64,
                                                        height: 64
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] h-16 w-16 rounded-full cursor-pointer",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    onClick: ()=>{
                                                        setCopied(true);
                                                        navigator.clipboard.writeText(`${baseURL}${router.asPath}`);
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        onClickAway: handleTooltipClose,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HtmlTooltip, {
                                                            PopperProps: {
                                                                disablePortal: true
                                                            },
                                                            placement: "top-start",
                                                            leaveTouchDelay: 2000,
                                                            onClose: handleTooltipClose,
                                                            open: open,
                                                            disableFocusListener: true,
                                                            disableHoverListener: true,
                                                            disableTouchListener: true,
                                                            arrow: true,
                                                            title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex justify-center items-center gap-3 bg-gray-900 p-4 rounded-lg",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "flex justify-center",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                                src: _assets_images_yellow_check_svg__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
                                                                                width: 15.7,
                                                                                height: 12
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                            sx: {
                                                                                color: "#FFF",
                                                                                bgcolor: "#002049",
                                                                                fontWeight: "light"
                                                                            },
                                                                            children: router.locale == "en" ? "Copied to clipboard" : "\u0421\u043A\u043E\u043F\u0456\u0439\u043E\u0432\u0430\u043D\u043E \u0432 \u0431\u0443\u0444\u0435\u0440 \u043E\u0431\u043C\u0456\u043D\u0443"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "h-16 w-16 flex items-center justify-center",
                                                                onClick: handleTooltipOpen,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                    src: copied ? _assets_images_slug_Vector_active_webp__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z : _assets_images_slug_Vector_webp__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
                                                                    alt: "copy to clipboard",
                                                                    title: "copy to clipboard",
                                                                    width: 18.86,
                                                                    height: 24
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RelatedPosts__WEBPACK_IMPORTED_MODULE_9__/* .RelatedPosts */ .Z, {
                                    slug: post.slug,
                                    category: post.category.name,
                                    tags: post.tags.map((tag)=>tag.slug)
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1765:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ RelatedPosts)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3877);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4030);
/* harmony import */ var _assets_images_card_location_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8745);
/* harmony import */ var _HeadingToggler__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3884);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_6__, swiper__WEBPACK_IMPORTED_MODULE_7__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_6__, swiper__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const RelatedPosts = ({ category , tags , slug  })=>{
    const { 0: relatedPosts , 1: setRelatedPosts  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_services__WEBPACK_IMPORTED_MODULE_8__/* .getRelatedPosts */ .EE)(category, tags, slug).then((result)=>setRelatedPosts(result));
    }, [
        slug
    ]);
    const totalSlides = relatedPosts.length < 3 ? "auto" : 3;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "hidden md:flex justify-center pl-6 md:px-6 xl:px-0 pt-28",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-center flex-col max-w-[1260px] w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeadingToggler__WEBPACK_IMPORTED_MODULE_10__/* .HeadingToggler */ .B, {
                        heading: "Related articles",
                        togglerPrevClass: "event-prev",
                        togglerNextClass: "event-next",
                        relatedPosts: relatedPosts
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-between gap-2 xl:gap-0 -ml-[23px] md:ml-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__.Swiper, {
                            className: "home-events-swiper h-full",
                            breakpoints: {
                                100: {
                                    slidesPerView: "auto",
                                    centeredSlides: true,
                                    spaceBetween: 8
                                },
                                700: {
                                    spaceBetween: 8
                                },
                                900: {
                                    slidesPerView: totalSlides,
                                    centeredSlides: false,
                                    spaceBetween: 60
                                }
                            },
                            pagination: {
                                clickable: true
                            },
                            navigation: {
                                prevEl: ".event-prev",
                                nextEl: ".event-next"
                            },
                            modules: [
                                swiper__WEBPACK_IMPORTED_MODULE_7__.Navigation,
                                swiper__WEBPACK_IMPORTED_MODULE_7__.Pagination
                            ],
                            children: relatedPosts.map((post)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__.SwiperSlide, {
                                    className: "py-10",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "shadow-[0px_2px_22px_rgba(0,32,73,0.13)] w-full max-h-full h-full overflow-hidden bg-gray-100 rounded-3xl mt-6 md:flex hidden flex-col justify-start",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full flex flex-col",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "w-full min-h-[200px] md:min-h-[256px] object-cover max-h-[200px] md:max-h-[256px]",
                                                    src: post.featuredImage.url,
                                                    alt: locale == "ua" ? post?.localizations[0]?.title : post.title,
                                                    title: locale == "ua" ? post.localizations[0]?.title : post.title,
                                                    loading: "lazy"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "px-4 lg:px-6 pt-6 flex flex-col justify-between h-full",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: `font-proximaNova200 text-yellow-900
                        px-6 py-2 rounded-[20px] ${post.tags[0]?.name ? "bg-yellow-100" : "bg-none"}`,
                                                                    children: locale == "ua" ? post.localizations[0]?.tags[0]?.name : post.tags[0]?.name
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "pt-8",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "font-proximaNova500 uppercase text-xl md:text-2xl",
                                                                        children: locale == "ua" ? post?.localizations[0]?.title : post.title
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "pr-4 md:pr-0 font-proximaNova200 text-base md:text-lg pt-2 leading-[18px]",
                                                                        children: locale == "ua" ? post?.localizations[0]?.excerpt : post.excerpt
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-full md:w-auto flex justify-between items-center pt-10 pb-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "font-proximaNova200 text-base text-gray-500 md:text-lg leading-[18px]",
                                                                    children: moment__WEBPACK_IMPORTED_MODULE_5___default()(post.createdAt).format("MMM DD, YYYY")
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    href: `/posts/${post.slug}`,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "bg-[#006DB6] text-gray-100 py-3 px-8 lg:px-10 rounded-[64px] font-proximaNova400 text-base md:text-lg text-center cursor-pointer",
                                                                        children: locale == "ua" ? "\u0427\u0438\u0442\u0430\u0442\u0438 \u0434\u0430\u043B\u0456" : "Read more"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, post.title))
                        })
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2881:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ PostDetails),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4030);
/* harmony import */ var _components_utils_PostDetail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9596);
/* harmony import */ var _services_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(487);
/* harmony import */ var _404__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5450);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7663);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_utils_PostDetail__WEBPACK_IMPORTED_MODULE_6__]);
_components_utils_PostDetail__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











function PostDetails({ post  }) {
    if (useIsPostInvalid(post)) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_404__WEBPACK_IMPORTED_MODULE_7__["default"], {});
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                        children: [
                            post.title,
                            " - Ukrainian Association of Moncton"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: post.excerpt
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_utils_PostDetail__WEBPACK_IMPORTED_MODULE_6__/* .PostDetail */ .Z, {
                    post: post
                })
            })
        ]
    });
};
function useIsPostInvalid(post) {
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    return (0,_services_helpers__WEBPACK_IMPORTED_MODULE_9__/* .isPostInvalid */ .Y)(locale, post);
}
async function _getStaticProps({ params  }) {
    const postData = await (0,_services_index__WEBPACK_IMPORTED_MODULE_5__/* .getPostDetails */ .zb)(params.slug);
    return {
        props: {
            post: postData
        },
        revalidate: _services_constants__WEBPACK_IMPORTED_MODULE_10__/* .REVALIDATION_TIME_POST */ .JI
    };
}
async function getStaticPaths() {
    const receivedPosts = await (0,_services_index__WEBPACK_IMPORTED_MODULE_5__/* .getPosts */ .Jq)();
    const posts = receivedPosts.filter((post)=>post.category);
    return {
        paths: posts.map(({ node: { slug  }  })=>({
                params: {
                    slug
                }
            })),
        fallback: "blocking"
    };
}
async function getStaticProps(ctx) {
    let res = _getStaticProps(ctx);
    if (typeof res.then === "function") res = await res;
    return {
        ...res,
        props: {
            ...res.props || {},
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/posts/[slug]",
                loaderName: "getStaticProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5371:
/***/ ((module) => {

module.exports = require("@mui/material/ClickAwayListener");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 8797:
/***/ ((module) => {

module.exports = require("next-share");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [894,27,350,543,52,30,450,884], () => (__webpack_exec__(2881)));
module.exports = __webpack_exports__;

})();