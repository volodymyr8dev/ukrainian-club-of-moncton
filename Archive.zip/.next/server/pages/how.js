"use strict";
(() => {
var exports = {};
exports.id = 5;
exports.ids = [5];
exports.modules = {

/***/ 1216:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ How),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./i18n.json
var i18n = __webpack_require__(608);
// EXTERNAL MODULE: external "next-translate/loadNamespaces"
var loadNamespaces_ = __webpack_require__(7462);
var loadNamespaces_default = /*#__PURE__*/__webpack_require__.n(loadNamespaces_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(9114);
// EXTERNAL MODULE: external "next-translate/useTranslation"
var useTranslation_ = __webpack_require__(866);
var useTranslation_default = /*#__PURE__*/__webpack_require__.n(useTranslation_);
;// CONCATENATED MODULE: ./components/utils/BlueDonationGrid.jsx



const GET_BLUE_CARDS_QUERY = client_.gql`
  query GetBlueCards {
    howCanIHelpCards (
      orderBy: createdAt_ASC,
      first: 9,
      # where: { color: "blue" }
    ) {
      cardText
      url
      color
      icon {
        url
      }
    }
  }
`;
const BlueDonationGrid = ()=>{
    const { data , loading , error  } = (0,client_.useQuery)(GET_BLUE_CARDS_QUERY);
    let { t  } = useTranslation_default()("how");
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: data.howCanIHelpCards.slice(0, 15).map((card, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 pt-8 rounded-3xl flex justify-between items-center flex-col px-8 pb-8 tablets:pb-0a lg:min-w-[250px] xl:min-w-[270px] 2xl:min-w-[350px] min-h-[376px] max-h-full tablets:max-h-[376px] h-full flex-1 shrink-0 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-blue-500 z-10 rounded-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: card.icon.url,
                                alt: card.cardText,
                                title: card.cardText,
                                className: "w-[128px] h-[128px] p-10 z-20"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-center font-proximaNova200 text-lg leading-[18px]",
                            children: card.cardText
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "w-full max-w-[224px] py-4 px-16 bg-blue-500 rounded-[64px] font-proximaNova400 text-lg leading-[18px] text-gray-100 text-center",
                            href: card.url,
                            target: "_blank",
                            rel: "noreferrer",
                            children: t("learn-more")
                        })
                    ]
                }, i))
        })
    });
};

;// CONCATENATED MODULE: ./components/utils/GreenDonationGrid.jsx



const GET_GREEN_CARDS_QUERY = client_.gql`
  query GetGreenCards {
    howCanIHelpCards (
      orderBy: createdAt_ASC,
      first: 9,
      where: { color: "green" }
    ) {
      cardText
      url
      color
      icon {
        url
      }
    }
  }
`;
const GreenDonationGrid = ()=>{
    const { data , loading , error  } = useQuery(GET_GREEN_CARDS_QUERY);
    let { t  } = useTranslation("how");
    if (loading) return /*#__PURE__*/ _jsx("span", {});
    if (error) return /*#__PURE__*/ _jsx("span", {});
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(_Fragment, {
                children: data.howCanIHelpCards.slice(0, 3).map((card, i)=>/*#__PURE__*/ _jsxs("div", {
                        className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 pt-8 rounded-3xl flex justify-between items-center flex-col px-8 pb-8 tablets:pb-0a lg:min-w-[290px] xl:min-w-[350px] min-h-[376px] max-h-full tablets:max-h-[376px] h-full flex-1 shrink-0 w-auto",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "bg-blue-500 z-10 rounded-full",
                                children: /*#__PURE__*/ _jsx("img", {
                                    src: card.icon.url,
                                    alt: card.cardText,
                                    title: card.cardText,
                                    className: "w-[128px] h-[128px] p-10 z-20"
                                })
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: "text-center font-proximaNova200 text-lg leading-[18px]",
                                children: card.cardText
                            }),
                            /*#__PURE__*/ _jsx("a", {
                                className: "w-full max-w-[224px] py-4 px-16 bg-blue-500 rounded-[64px] font-proximaNova400 text-lg leading-[18px] text-gray-100 text-center",
                                href: card.url,
                                target: "_blank",
                                rel: "noreferrer",
                                children: t("learn-more")
                            })
                        ]
                    }, i))
            }),
            data.howCanIHelpCards.length <= 3 ? /*#__PURE__*/ _jsx(_Fragment, {}) : /*#__PURE__*/ _jsx("div", {
                className: "flex w-full gap-8 md:gap-5 tablets:gap-10 justify-start flex-col tablets:flex-row pt-8 tablets:pt-10",
                children: data.howCanIHelpCards.slice(3, 6).map((card, i)=>/*#__PURE__*/ _jsxs("div", {
                        className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 pt-8 rounded-3xl flex justify-between items-center flex-col px-8 pb-8 tablets:pb-0a lg:min-w-[290px] xl:min-w-[350px] min-h-[376px] max-h-full tablets:max-h-[376px] h-full flex-1 shrink-0 tablets:max-w-[32%]",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "bg-green-500 z-10 rounded-full",
                                children: /*#__PURE__*/ _jsx("img", {
                                    src: card.icon.url,
                                    alt: card.cardText,
                                    title: card.cardText,
                                    className: "w-[128px] h-[128px] p-10 z-20"
                                })
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: "text-center font-proximaNova200 text-lg leading-[18px]",
                                children: card.cardText
                            }),
                            /*#__PURE__*/ _jsx("a", {
                                className: "w-full max-w-[224px] py-4 px-16 bg-green-500 rounded-[64px] font-proximaNova400 text-lg leading-[18px] text-gray-100 text-center",
                                href: card.url,
                                target: "_blank",
                                rel: "noreferrer",
                                children: t("learn-more")
                            })
                        ]
                    }, i))
            }),
            data.howCanIHelpCards.length <= 6 ? /*#__PURE__*/ _jsx(_Fragment, {}) : /*#__PURE__*/ _jsx("div", {
                className: "flex w-full gap-8 md:gap-5 tablets:gap-10 justify-start flex-col tablets:flex-row pt-8 tablets:pt-10",
                children: data.howCanIHelpCards.slice(6, 9).map((card, i)=>/*#__PURE__*/ _jsxs("div", {
                        className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 pt-8 rounded-3xl flex justify-between items-center flex-col px-8 pb-8 tablets:pb-0a lg:min-w-[290px] xl:min-w-[350px] min-h-[376px] max-h-full tablets:max-h-[376px] h-full w-full flex-1 shrink-0 ",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "bg-green-500 z-10 rounded-full",
                                children: /*#__PURE__*/ _jsx("img", {
                                    src: card.icon.url,
                                    alt: card.cardText,
                                    title: card.cardText,
                                    className: "w-[128px] h-[128px] p-10 z-20"
                                })
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: "text-center font-proximaNova200 text-lg leading-[18px]",
                                children: card.cardText
                            }),
                            /*#__PURE__*/ _jsx("a", {
                                className: "w-full max-w-[224px] py-4 px-16 bg-green-500 rounded-[64px] font-proximaNova400 text-lg leading-[18px] text-gray-100 text-center",
                                href: card.url,
                                target: "_blank",
                                rel: "noreferrer",
                                children: t("learn-more")
                            })
                        ]
                    }, i))
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/utils/YellowDonationGrid.jsx



const GET_YELLOW_CARDS_QUERY = client_.gql`
  query GetYellowCards {
    howCanIHelpCards (
      orderBy: createdAt_ASC,
      first: 9,
      where: { color: "yellow" }
    ) {
      cardText
      url
      color
      icon {
        url
      }
    }
  }
`;
const YellowDonationGrid = ()=>{
    const { data , loading , error  } = useQuery(GET_YELLOW_CARDS_QUERY);
    let { t  } = useTranslation("how");
    if (loading) return /*#__PURE__*/ _jsx("span", {});
    if (error) return /*#__PURE__*/ _jsx("span", {});
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(_Fragment, {
                children: data.howCanIHelpCards.slice(0, 3).map((card, i)=>/*#__PURE__*/ _jsxs("div", {
                        className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 pt-8 rounded-3xl flex justify-between items-center flex-col px-8 pb-8 tablets:pb-0a lg:min-w-[290px] xl:min-w-[350px] min-h-[376px] max-h-full tablets:max-h-[376px] h-full flex-1 shrink-0",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "bg-blue-500 z-10 rounded-full",
                                children: /*#__PURE__*/ _jsx("img", {
                                    src: card.icon.url,
                                    alt: card.cardText,
                                    title: card.cardText,
                                    className: "w-[128px] h-[128px] p-10 z-20"
                                })
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: "text-center font-proximaNova200 text-lg leading-[18px]",
                                children: card.cardText
                            }),
                            /*#__PURE__*/ _jsx("a", {
                                className: "w-full max-w-[224px] py-4 px-16 bg-blue-500 rounded-[64px] font-proximaNova400 text-lg leading-[18px] text-gray-100 text-center",
                                href: card.url,
                                target: "_blank",
                                rel: "noreferrer",
                                children: t("learn-more")
                            })
                        ]
                    }, i))
            }),
            data.howCanIHelpCards.length <= 3 ? /*#__PURE__*/ _jsx(_Fragment, {}) : /*#__PURE__*/ _jsx("div", {
                className: "flex w-full gap-8 md:gap-5 tablets:gap-10 justify-start flex-col tablets:flex-row pt-8 tablets:pt-10",
                children: data.howCanIHelpCards.slice(3, 6).map((card, i)=>/*#__PURE__*/ _jsxs("div", {
                        className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 pt-8 rounded-3xl flex justify-between items-center flex-col px-8 pb-8 tablets:pb-0a lg:min-w-[290px] xl:min-w-[350px] min-h-[376px] max-h-full tablets:max-h-[376px] h-full w-full flex-1 shrink-0 ",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "bg-yellow-300 z-10 rounded-full",
                                children: /*#__PURE__*/ _jsx("img", {
                                    src: card.icon.url,
                                    alt: card.cardText,
                                    title: card.cardText,
                                    className: "w-[128px] h-[128px] p-10 z-20"
                                })
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: "text-center font-proximaNova200 text-lg leading-[18px]",
                                children: card.cardText
                            }),
                            /*#__PURE__*/ _jsx("a", {
                                className: "w-full max-w-[224px] py-4 px-16 bg-yellow-300 rounded-[64px] font-proximaNova400 text-lg leading-[18px] text-gray-100 text-center",
                                href: card.url,
                                target: "_blank",
                                rel: "noreferrer",
                                children: t("learn-more")
                            })
                        ]
                    }, i))
            }),
            data.howCanIHelpCards.length <= 6 ? /*#__PURE__*/ _jsx(_Fragment, {}) : /*#__PURE__*/ _jsx("div", {
                className: "flex w-full gap-8 md:gap-5 tablets:gap-10 justify-start flex-col tablets:flex-row pt-8 ",
                children: data.howCanIHelpCards.slice(6, 9).map((card, i)=>/*#__PURE__*/ _jsxs("div", {
                        className: "shadow-[0px_2px_32px_rgba(0,32,73,0.13)] bg-gray-100 pt-8 rounded-3xl flex justify-between items-center flex-col px-8 pb-8 tablets:pb-0a lg:min-w-[290px] xl:min-w-[350px] min-h-[376px] max-h-full tablets:max-h-[376px] h-full w-full flex-1 shrink-0 tablets:max-w-[32%]",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "bg-yellow-300 z-10 rounded-full",
                                children: /*#__PURE__*/ _jsx("img", {
                                    src: card.icon.url,
                                    alt: card.cardText,
                                    title: card.cardText,
                                    className: "w-[128px] h-[128px] p-10 z-20"
                                })
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: "text-center font-proximaNova200 text-lg leading-[18px]",
                                children: card.cardText
                            }),
                            /*#__PURE__*/ _jsx("a", {
                                className: "w-full max-w-[224px] py-4 px-16 bg-yellow-300 rounded-[64px] font-proximaNova400 text-lg leading-[18px] text-gray-100 text-center",
                                href: card.url,
                                target: "_blank",
                                rel: "noreferrer",
                                children: t("learn-more")
                            })
                        ]
                    }, i))
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/sections/how/DonationSupport.jsx






const DonationSupport = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: " mb-[72px] md:mb-24 px-6 md:px-6 xl:px-0",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "font-proximaNova400 text-[32px] md:text-[40px] leading-[100%] mb-[64px] tracking-wider uppercase text-center",
                children: data["donation-support-blue"]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " flex flex-wrap justify-center gap-x-9 gap-y-10 w-[70%] mx-auto ",
                children: /*#__PURE__*/ jsx_runtime_.jsx(BlueDonationGrid, {})
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/images/how-bg.webp
/* harmony default export */ const how_bg = ({"src":"/_next/static/media/how-bg.9b9b2147.webp","height":504,"width":1728,"blurDataURL":"data:image/webp;base64,UklGRkIAAABXRUJQVlA4IDYAAACwAQCdASoIAAIAAkA4JQBOgB6GNcUAAP51hBjQcXcxzPM5DOp4ow1XRBGWtOpNhB3Kf/GQAAA="});
;// CONCATENATED MODULE: ./assets/images/how-bg-mobile.webp
/* harmony default export */ const how_bg_mobile = ({"src":"/_next/static/media/how-bg-mobile.bb71984b.webp","height":204,"width":375,"blurDataURL":"data:image/webp;base64,UklGRlQAAABXRUJQVlA4IEgAAACwAQCdASoIAAQAAkA4JbACdAD0klH4APff9prdlD/yunq8D9WtAEtYSF9JABfcUHa9UKMh67cZG+Q+YwMFYtmzxZrRXEgAAAA="});
;// CONCATENATED MODULE: ./components/sections/how/HowFront.jsx




const HowFront = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "flex justify-center items-center mb-12 md:mb-[60px]",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-between gap-6 flex-col",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between w-screen info-front-farm",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "hidden tablets:block w-full overflow-hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: how_bg,
                                alt: "farm",
                                layout: "responsive",
                                priority: true
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "block tablets:hidden w-full overflow-hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: how_bg_mobile,
                                alt: "farm",
                                layout: "responsive",
                                priority: true
                            })
                        })
                    ]
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./components/sections/how/Informative.jsx



const Informative = ()=>{
    const { locale  } = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "flex justify-center mb-[72px] md:mb-24 px-6 md:px-6 xl:px-0",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-center flex-col max-w-[1216px] w-full",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    className: "font-proximaNova500 text-4xl md:text-[56px] leading-[100%] tracking-wider uppercase text-left md:text-center",
                    children: [
                        data["how-title-black"],
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-blue-500",
                            children: data["how-title-blue"]
                        }),
                        " ",
                        data["how-help-us"]
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "pt-8 md:pt-11",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "w-full md:w-[98%] text-left md:text-center font-proximaNova300 text-xl md:text-2xl leading-9",
                        children: data["how-introduce"]
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./pages/how.jsx









function How() {
    const router = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(router.locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "How can I help? - Ukrainian Association of Moncton"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: data["how-tag-seo"]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                id: "main",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(HowFront, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "how-section",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "how-section-bg",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Informative, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(DonationSupport, {})
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
async function getStaticProps(ctx) {
    return {
        props: {
            ...await loadNamespaces_default()({
                ...ctx,
                pathname: "/how",
                loaderName: "getStaticProps",
                ...i18n,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [894,27,52], () => (__webpack_exec__(1216)));
module.exports = __webpack_exports__;

})();