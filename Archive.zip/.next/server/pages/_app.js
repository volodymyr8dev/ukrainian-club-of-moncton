"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 2280:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./i18n.json
var i18n = __webpack_require__(608);
// EXTERNAL MODULE: external "next-translate/appWithI18n"
var appWithI18n_ = __webpack_require__(5668);
var appWithI18n_default = /*#__PURE__*/__webpack_require__.n(appWithI18n_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(9114);
;// CONCATENATED MODULE: ./services/apollo.js

const api = {
    contentApiURI: "https://api-ca-central-1.hygraph.com/v2/cl76cbzf567do01uobh04hzvo/master",
    contentApiAuthToken: "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImdjbXMtbWFpbi1wcm9kdWN0aW9uIn0.eyJ2ZXJzaW9uIjozLCJpYXQiOjE2NjEyNjg0MzgsImF1ZCI6WyJodHRwczovL2FwaS1jYS1jZW50cmFsLTEuaHlncmFwaC5jb20vdjIvY2w3NmNiemY1NjdkbzAxdW9iaDA0aHp2by9tYXN0ZXIiLCJtYW5hZ2VtZW50LW5leHQuZ3JhcGhjbXMuY29tIl0sImlzcyI6Imh0dHBzOi8vbWFuYWdlbWVudC5ncmFwaGNtcy5jb20vIiwic3ViIjoiNDIyYjQ5Y2MtMzQwMC00NzYzLTk2YjQtMWNjYWNjYTUwYjI4IiwianRpIjoiY2w2Yzh6ZDl5MHUxeTAxdWhiY3FvM2p1cCJ9.AODwozk24Qa4txTJJmNu9k0dhBJYObON3WdomCZMv0EK-4EHjk_MKmFZAJ5UuyNq-Tdr5H0k-3epaca4xYuJNYzsUE6h35Rz8XdzC4FPyksg3U4MzpqsS0b1T_hDbHONVWdBcCMGNwiE0jjno36IwD5OHJrX2r8w8BN6Rfmt2p7Fse7QOMliUstTWDeERO4AuGXpONjyLaa2R2rPMxEs3PA8t18jF9IJ_JFajI71MAZfWcFpZ_xbUPdM5kMYGg2Bvy8YZmHm1s1BHLzs2eaHsRSSUqUirVowOqt30TVckHvSp2tDKJwdfbU4ne34D4z2O_vDgFcEW5SFnqaOJFlfA76eYbS7_m0FYgPj_Nwv8pZtuOl_YrlyqR1XkN_khjlMJ-eK-oDc2SSO0jb8qK_UwpwDcf1GI2xTq-dzBBqIIe2FJRjiLOr-1S2atuJLaLi_wbnlFZsFEnFLKjZftIMKn57Hq0HywIO63Nkz-g8-vqjHCFZQ4lMe3J3-fMF7aHGMxX6Wh9wGlSTxboZpMEBMBjjKlz3232BUiHIoipfDBJqtdNAD5W01DdeU2bDMwus1Xz1XQqp0ovCnf6B6UNqTXNpIjZUeBCiuThJFPq4u-KECF2mY-TJa5e21t7U6fjS3UdbTSm6Qec9vf5Mo4za1x_4mKE4-5Wp9LTXAFicEEsI"
};
const client = new client_.ApolloClient({
    uri: api.contentApiURI,
    headers: {
        "Authorization": `Bearer ${api.contentApiAuthToken}`
    },
    cache: new client_.InMemoryCache()
});

;// CONCATENATED MODULE: external "nextjs-progressbar"
const external_nextjs_progressbar_namespaceObject = require("nextjs-progressbar");
var external_nextjs_progressbar_default = /*#__PURE__*/__webpack_require__.n(external_nextjs_progressbar_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(543);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next-translate/useTranslation"
var useTranslation_ = __webpack_require__(866);
var useTranslation_default = /*#__PURE__*/__webpack_require__.n(useTranslation_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
;// CONCATENATED MODULE: ./assets/images/footer/ukr-monc-logo.png
/* harmony default export */ const ukr_monc_logo = ({"src":"/_next/static/media/ukr-monc-logo.fefa64ff.png","height":181,"width":194,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAx0lEQVR42mP4//8/AwPDXkYQnXP8S2jRpV8+DGf/c4P4Ky9fZGIAK3j+n8l868sZHWcf/1t85dr/h9eLp/y/zgBWBFZg1ndRWX7+/U9Tjh37f+Taov/fnkr8fvs0Rg6uYPmLfxwMRUf2NCze+v/Jywn/f75z3v3+qZcwWMH8XXeZIO7oFr17s6no/9fggtePGWRBYt8/dLCATfj1+48ikNYHYr3f//9rAWmjf3+/q8GsAGFNoCK7P3//+vz798vt37/frlANDAD9JJiFGcoWFwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./assets/images/footer/vercel-logo.svg
/* harmony default export */ const vercel_logo = ({"src":"/_next/static/media/vercel-logo.10f964be.svg","height":21,"width":89});
;// CONCATENATED MODULE: ./assets/images/footer/bf-logo.svg
/* harmony default export */ const bf_logo = ({"src":"/_next/static/media/bf-logo.ab3cf42d.svg","height":27,"width":123});
;// CONCATENATED MODULE: ./assets/images/footer/email.svg
/* harmony default export */ const email = ({"src":"/_next/static/media/email.407dc99b.svg","height":19,"width":20});
;// CONCATENATED MODULE: ./assets/images/footer/facebook.svg
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.c71417bc.svg","height":25,"width":24});
;// CONCATENATED MODULE: ./assets/images/footer/instagram.svg
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.ce104116.svg","height":25,"width":24});
;// CONCATENATED MODULE: ./components/layout/Footer.jsx












const Footer = ()=>{
    const { t  } = useTranslation_default()("common");
    const { locale  } = (0,router_.useRouter)();
    const { data: dataFrom100 , loading: loadingFrom100 , error: errorFrom100  } = (0,getTexts/* getTexts */.r)(locale, 100);
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading || loadingFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error || errorFrom100) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("footer", {
                className: "bg-gray-900 justify-center h-full px-6 xl:px-0 hidden md:flex",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "bg-gray-900 max-w-[1216px] w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-gray-900 h-24 border-b-[1px] border-[#666177]"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-900 w-full flex justify-center items-center gap-32 py-[60px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "cursor-pointer",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: ukr_monc_logo,
                                                width: 194,
                                                alt: dataFrom100["assosiation-of-moncton"]
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col justify-start items-center gap-4",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-[18px] justify-start w-full",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: email,
                                                    width: 24,
                                                    alt: "email"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: `mailto:${data["about-email-box"]}`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-100",
                                                        children: data["footer-email"]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex justify-start gap-6 pr-4",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex gap-[18px]",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: instagram,
                                                        width: 24,
                                                        alt: "instagram"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: `${dataFrom100["instagram-navigation"]}`,
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-proximaNova300 text-sm leading-[14px] text-gray-100",
                                                            children: data["footer-instagram-box"]
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex justify-start gap-[18px] w-full",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: facebook,
                                                    width: 24,
                                                    alt: "facebook"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: `${data["facebook-navigation"]}`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-100",
                                                        children: data["footer-facebook-description"]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-900 h-32 border-t-[1px] border-[#666177] flex justify-between items-center w-full",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-[33%]",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-500",
                                        children: "Powered by"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-center items-center gap-3 w-[33%]",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://vercel.com/?utm_source=binary-future-moncton&utm_campaign=oss",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: vercel_logo,
                                                    width: 90,
                                                    alt: "Vercel"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "-mt-[7px]",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-proximaNova300 text-sm leading-[14px] text-gray-500",
                                                children: "/"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://binaryfuture.io",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: bf_logo,
                                                    width: 115,
                                                    alt: "Vercel"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-end w-[33%]",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-500 w-full text-right",
                                        children: dataFrom100["footer-assosiation-of-moncton"]
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("footer", {
                className: "bg-gray-900 justify-center h-full px-6 xl:px-0 flex md:hidden",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "bg-gray-900 max-w-[1216px] w-full",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-900 w-full flex flex-col justify-center items-center gap-10 py-[40px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "cursor-pointer",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: ukr_monc_logo,
                                                width: 194,
                                                alt: dataFrom100["assosiation-of-moncton"]
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col justify-start items-start gap-[26px]",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-[18px] justify-start w-full",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: email,
                                                    width: 24,
                                                    alt: "address"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: `mailto:${data["about-email-box"]}`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-100",
                                                        children: data["footer-email"]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-[18px]",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: instagram,
                                                    width: 24,
                                                    alt: "instagram"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: `${dataFrom100["instagram-navigation"]}`,
                                                    target: "_blank",
                                                    rel: "noreferrer",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-100",
                                                        children: data["footer-instagram-box"]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-[18px]",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: facebook,
                                                    width: 24,
                                                    alt: "facebook"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: `${data["facebook-navigation"]}`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-100",
                                                        children: data["footer-facebook-description"]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-900 h-[188px] border-t-[1px] border-[#666177] flex flex-col justify-center items-center w-full",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-500",
                                        children: "Powered by"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-center items-center gap-3 pt-[18px] pb-[39px]",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://vercel.com/?utm_source=ukrainian-club-of-moncton&utm_campaign=oss",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: vercel_logo,
                                                    width: 90,
                                                    alt: "Vercel"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "-mt-[7px]",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-proximaNova300 text-sm leading-[14px] text-gray-500",
                                                children: "/"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://binaryfuture.io",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: bf_logo,
                                                    width: 115,
                                                    alt: "Binary Future"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-end",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-proximaNova300 text-sm leading-[14px] text-gray-500 w-full text-center",
                                        children: dataFrom100["footer-assosiation-of-moncton"]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/utils/DonateButton.jsx + 1 modules
var DonateButton = __webpack_require__(8039);
;// CONCATENATED MODULE: external "@mui/material"
const material_namespaceObject = require("@mui/material");
;// CONCATENATED MODULE: external "@mui/material/MenuItem"
const MenuItem_namespaceObject = require("@mui/material/MenuItem");
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/FormControl"
const FormControl_namespaceObject = require("@mui/material/FormControl");
var FormControl_default = /*#__PURE__*/__webpack_require__.n(FormControl_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Select"
const Select_namespaceObject = require("@mui/material/Select");
var Select_default = /*#__PURE__*/__webpack_require__.n(Select_namespaceObject);
;// CONCATENATED MODULE: ./components/utils/LanguageSwitch.jsx








const LanguageSwitch = ()=>{
    const { locale , locales , asPath  } = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        className: "flex align-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx((FormControl_default()), {
                sx: {
                    border: 0,
                    m: 0,
                    minWidth: 40
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Select_default()), {
                    sx: {
                        borderColor: "white",
                        border: 0
                    },
                    value: locale,
                    displayEmpty: true,
                    disableInjectingGlobalStyles: true,
                    inputProps: {
                        "aria-label": "Without label",
                        MenuProps: {
                            disableScrollLock: true
                        }
                    },
                    children: locales.map((l, i)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                            className: l === locale ? "styles.selected" : "",
                            value: l,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: asPath,
                                locale: l,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "font-proximaNova500 text-base md:text-xl pr-2 md:pr-0 flex items-center uppercase",
                                    children: l
                                })
                            })
                        }, i);
                    })
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./assets/images/mobile-menu/close.svg
/* harmony default export */ const mobile_menu_close = ({"src":"/_next/static/media/close.60fbe63c.svg","height":12,"width":12});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/home-black.svg
/* harmony default export */ const home_black = ({"src":"/_next/static/media/home-black.609345ab.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/events-black.svg
/* harmony default export */ const events_black = ({"src":"/_next/static/media/events-black.307ebefb.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/info-black.svg
/* harmony default export */ const info_black = ({"src":"/_next/static/media/info-black.ad33698a.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/about-black.svg
/* harmony default export */ const about_black = ({"src":"/_next/static/media/about-black.822657d8.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/help-black.svg
/* harmony default export */ const help_black = ({"src":"/_next/static/media/help-black.df3f41f7.svg","height":20,"width":20});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/home-white.svg
/* harmony default export */ const home_white = ({"src":"/_next/static/media/home-white.a3cab96d.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/events-white.svg
/* harmony default export */ const events_white = ({"src":"/_next/static/media/events-white.b1f6317a.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/info-white.svg
/* harmony default export */ const info_white = ({"src":"/_next/static/media/info-white.3b8f79d2.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/about-white.svg
/* harmony default export */ const about_white = ({"src":"/_next/static/media/about-white.c64db817.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./assets/images/mobile-menu/help-white.svg
/* harmony default export */ const help_white = ({"src":"/_next/static/media/help-white.2782590b.svg","height":20,"width":20});
;// CONCATENATED MODULE: ./components/utils/MobileMenu.jsx


















const MobileMenu = ({ setIsActive  })=>{
    const { t  } = useTranslation_default()("common");
    const router = (0,router_.useRouter)();
    const handleClose = ()=>{
        setIsActive(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            onClick: handleClose,
            className: "opacity-60 bg-white-opacity h-screen w-full fixed top-0 bottom-0 m-auto z-10",
            children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: "separate-mobile-menu relative flex justify-center h-[72px] md:h-full shadow-[0px_4px_4px_rgba(0,0,0,0.06)] -mt-[72px] bg-gray-100 z-40",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    className: `flex justify-between items-center max-w-[1216px] w-full px-6
          xl:px-0 bg-white-opacity`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `mobile-menu-bg bg-gray-100 md:flex flex fixed
          max-w-[236px] w-full h-full top-0 -mx-7 justify-center z-10`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex items-center gap-4 md:gap-16 flex-col md:flex-row translate-y-[200px] md:translate-y-0 bg-none md:bg-gray-100 h-screen md:h-full w-screen md:w-full pt-8 md:pt-0 -mt-[130px] md:mt-0 px-2 md:px-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "block md:hidden pb-11 md:pb-0",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "cursor-pointer font-proximaNova300 border-solid border-blue-500 border-[1px] text-base py-[12px] px-[15px] rounded-[50px] uppercase",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/how",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-blue-500",
                                                    children: t("volunteer-with")
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
              text-base md:text-xl text-center md:border-b-2 w-full md:w-auto
              px-7 md:px-0
              ${router.pathname == "/" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: router.pathname == "/" ? home_white : home_black,
                                                            alt: "home",
                                                            width: 18.2,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${router.pathname == "/" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("home")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
              text-base md:text-xl text-center md:border-b-2 w-full md:w-auto
              px-7 md:px-0
              ${router.pathname == "/info/[page]" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/info/1",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: router.pathname == "/info/[page]" ? info_white : info_black,
                                                            alt: "info",
                                                            width: 20,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${router.pathname == "/info/[page]" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("info")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
              text-base md:text-xl text-center md:border-b-2 w-full md:w-auto
              px-7 md:px-0
              ${router.pathname == "/events/[page]" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/events/1",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: router.pathname == "/events/[page]" ? events_white : events_black,
                                                            alt: "events",
                                                            width: 20,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${router.pathname == "/events/[page]" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("events")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
              text-base md:text-xl text-center md:border-b-2 w-full md:w-auto
              px-7 md:px-0
              ${router.pathname == "/our-help/[page]" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/our-help/1",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: router.pathname === "/our-help/[page]" ? help_white : help_black,
                                                            alt: "our help",
                                                            width: 20,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${router.pathname == "/our-help/[page]" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer capitalize`,
                                                        children: t("our-help")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
              text-base md:text-xl text-center md:border-b-2 w-full md:w-auto px-7
              md:px-0
              ${router.pathname == "/about" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/about",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: router.pathname == "/about" ? about_white : about_black,
                                                            alt: "about",
                                                            width: 20,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${router.pathname == "/about" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("about")
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex md:hidden z-20",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "flex items-center",
                                onClick: handleClose,
                                "aria-label": "toggle menu",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: mobile_menu_close,
                                    alt: "close",
                                    width: 16,
                                    height: 16
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: ``,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex items-center gap-0 small-phones:gap-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(LanguageSwitch, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(DonateButton/* DonateButton */.H, {})
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./assets/images/mobile-menu/open.svg
/* harmony default export */ const mobile_menu_open = ({"src":"/_next/static/media/open.e85897d8.svg","height":16,"width":16});
;// CONCATENATED MODULE: ./components/layout/Header.jsx



















const Header = ()=>{
    const { t  } = useTranslation_default()("common");
    const { locale , pathname , asPath  } = (0,router_.useRouter)();
    const { 0: isActive , 1: setIsActive  } = (0,external_react_.useState)(false);
    //Makes sure class is removed after changing to any pages/
    (0,external_react_.useEffect)(()=>{
        document.documentElement.classList.remove("lock-scroll");
    }, [
        asPath
    ]);
    const openMenu = ()=>{
        document.documentElement.classList.add("lock-scroll");
        setIsActive(true);
    };
    const closeMenu = ()=>{
        document.documentElement.classList.remove("lock-scroll");
        setIsActive(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: "relative flex justify-center h-[72px] md:h-full shadow-[0px_4px_4px_rgba(0,0,0,0.06)]",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    className: `flex justify-between items-center max-w-[1216px] w-full px-6
        xl:px-0`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `mobile-menu-bg bg-gray-100 md:flex ${isActive ? "flex fixed max-w-[236px] w-full h-full top-0 -mx-7 justify-center z-10" : "hidden"}`,
                            children: !isActive && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex items-center gap-4 md:gap-8 lg:gap-16 flex-col md:flex-row translate-y-[200px] md:translate-y-0 bg-none md:bg-gray-100 h-screen md:h-full w-screen md:w-full pt-8 md:pt-0 -mt-[130px] md:mt-0 px-2 md:px-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "block md:hidden pb-11 md:pb-0",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "cursor-pointer font-proximaNova300 border-solid border-blue-500 border-[1px] text-base py-[12px] px-[15px] rounded-[50px] uppercase",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/how",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-blue-500",
                                                    children: t("volunteer-with")
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
            text-base md:text-xl text-center md:border-b-2 w-full md:w-auto px-7
            md:px-0 capitalize
            ${pathname === "/" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            locale: locale,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: pathname === "/" ? home_white : home_black,
                                                            alt: "home",
                                                            width: 18.2,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${pathname === "/" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("home")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
            text-base md:text-xl text-center md:border-b-2 w-full md:w-auto px-7
            md:px-0 capitalize
            ${pathname === "/events/[page]" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/events/1",
                                            locale: locale,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: pathname === "/events/[page]" ? events_white : events_black,
                                                            alt: "events",
                                                            width: 20,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${pathname == "/events/[page]" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("events")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
            text-base md:text-xl text-center md:border-b-2 w-full md:w-auto px-7
            md:px-0 capitalize
            ${pathname === "/our-help/[page]" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/our-help/1",
                                            locale: locale,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: pathname === "/our-help/[page]" ? help_white : help_black,
                                                            alt: "our help",
                                                            width: 20,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${pathname == "/our-help/[page]" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("our-help")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: `py-6 font-proximaNova300 md:font-proximaNova500
            text-base md:text-xl text-center md:border-b-2 w-full md:w-auto px-7
            md:px-0 capitalize
            ${pathname === "/about" ? "md:text-blue-500 md:border-blue-500 bg-blue-500 md:bg-gray-100 rounded-lg md:rounded-none px-4 md:px-0" : ""}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/about",
                                            locale: locale,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex md:block items-center justify-start gap-4 md-gap-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex md:hidden items-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: pathname === "/about" ? about_white : about_black,
                                                            alt: "about",
                                                            width: 20,
                                                            height: 20
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `${pathname === "/about" ? "text-gray-100 md:text-blue-500" : ""} cursor-pointer`,
                                                        children: t("about")
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex md:hidden z-20",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "flex items-center",
                                onClick: isActive ? closeMenu : openMenu,
                                "aria-label": "toggle menu",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: isActive ? mobile_menu_close : mobile_menu_open,
                                    alt: isActive ? "close menu" : "open menu",
                                    width: 16,
                                    height: 16
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex items-center gap-0 small-phones:gap-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(LanguageSwitch, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(DonateButton/* DonateButton */.H, {})
                                ]
                            })
                        })
                    ]
                })
            }),
            isActive && /*#__PURE__*/ jsx_runtime_.jsx(MobileMenu, {
                setIsActive: setIsActive
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/layout/Layout.jsx



const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
        ]
    });
};

;// CONCATENATED MODULE: ./pages/_app.js











function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((external_nextjs_progressbar_default()), {
                color: "#5271F2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(client_.ApolloProvider, {
                client: client,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Layout, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            })
        ]
    });
}
const __Page_Next_Translate__ = MyApp;
/* harmony default export */ const _app = (appWithI18n_default()(__Page_Next_Translate__, {
    ...i18n,
    isLoader: true,
    skipInitialProps: true,
    loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
}));


/***/ }),

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5668:
/***/ ((module) => {

module.exports = require("next-translate/appWithI18n");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [894,27,350,543,52,39], () => (__webpack_exec__(2280)));
module.exports = __webpack_exports__;

})();