"use strict";
exports.id = 171;
exports.ids = [171];
exports.modules = {

/***/ 6171:
/***/ ((module) => {

module.exports = JSON.parse('{"learn-more":"Дізнатися більше"}');

/***/ })

};
;