"use strict";
exports.id = 450;
exports.ids = [450];
exports.modules = {

/***/ 5450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ FourOhFour),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./i18n.json
var i18n = __webpack_require__(608);
// EXTERNAL MODULE: external "next-translate/loadNamespaces"
var loadNamespaces_ = __webpack_require__(7462);
var loadNamespaces_default = /*#__PURE__*/__webpack_require__.n(loadNamespaces_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(543);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next-translate/useTranslation"
var useTranslation_ = __webpack_require__(866);
var useTranslation_default = /*#__PURE__*/__webpack_require__.n(useTranslation_);
;// CONCATENATED MODULE: ./assets/images/404-icon.svg
/* harmony default export */ const _404_icon = ({"src":"/_next/static/media/404-icon.15f5e01e.svg","height":166,"width":166});
;// CONCATENATED MODULE: ./pages/404.jsx








function FourOhFour() {
    const { t  } = useTranslation_default()("common");
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "h-screen w-screen -mt-[70px] not-found-bg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full h-full flex justify-center items-center flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-center items-center w-full gap-4 -mt-100",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-proximaNova300 text-[114px] md:text-[227px] text-center text-blue-500",
                                children: "4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-[83px] md:w-[166px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: _404_icon,
                                    alt: "0",
                                    layout: "intrinsic"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-proximaNova300 text-[114px] md:text-[227px] text-center text-blue-500",
                                children: "4"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "-mt-10 w-full text-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "text-center font-proximaNova300 text-xl md:text-2xl leading-9",
                            children: [
                                t("what-looking-for"),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                    className: "hidden md:block"
                                }),
                                t("try-below")
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col md:flex-row gap-4 md:gap-8 justify-center w-[240px] md:w-full pt-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "font-proximaNova400 text-gray-100 text-lg text-center uppercase bg-blue-500 border border-blue-500 rounded-full px-8 py-4 cursor-pointer",
                                    children: t("go-home")
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                onClick: router.back,
                                className: "font-proximaNova400 text-blue-500 text-lg text-center uppercase bg-gray-100 border border-blue-500 rounded-full px-8 py-4 cursor-pointer",
                                children: t("previous")
                            })
                        ]
                    })
                ]
            })
        })
    });
};
async function getStaticProps(ctx) {
    return {
        props: {
            ...await loadNamespaces_default()({
                ...ctx,
                pathname: "/404",
                loaderName: "getStaticProps",
                ...i18n,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}


/***/ })

};
;