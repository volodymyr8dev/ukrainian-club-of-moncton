"use strict";
exports.id = 39;
exports.ids = [39];
exports.modules = {

/***/ 8039:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* binding */ DonateButton)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/images/yellow-heart.svg
/* harmony default export */ const yellow_heart = ({"src":"/_next/static/media/yellow-heart.b21b6947.svg","height":22,"width":24});
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/getTexts.js
var getTexts = __webpack_require__(3947);
;// CONCATENATED MODULE: ./components/utils/DonateButton.jsx





const DonateButton = ({ link , img , text  })=>{
    const { locale  } = (0,router_.useRouter)();
    const { data , loading , error  } = (0,getTexts/* getTexts */.r)(locale);
    if (loading) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx("span", {});
    const paypalURL = "https://www.paypal.com/donate/?hosted_button_id=Z2UJBCH46UA78";
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            href: link ? link : paypalURL,
            target: "_blank",
            rel: "noreferrer",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "cursor-pointer font-proximaNova400 text-base md:text-xl bg-[#006DB6] py-3 md:py-[14px] px-3 smaller-phones:px-6 flex items-center small-phones:px-[32px] rounded-[50px] uppercase flex gap-2 justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-gray-100",
                        children: text ? text : data["donate-now"]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex items-center pr-[4px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: img ? img : yellow_heart,
                            alt: "heart",
                            width: 20,
                            height: 21
                        })
                    })
                ]
            })
        })
    });
};


/***/ })

};
;