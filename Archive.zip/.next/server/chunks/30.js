"use strict";
exports.id = 30;
exports.ids = [30];
exports.modules = {

/***/ 4030:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EE": () => (/* binding */ getRelatedPosts),
/* harmony export */   "FN": () => (/* binding */ hygraph),
/* harmony export */   "Jq": () => (/* binding */ getPosts),
/* harmony export */   "zb": () => (/* binding */ getPostDetails)
/* harmony export */ });
/* unused harmony export getPostDetailsUA */
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);

const hygraph = new graphql_request__WEBPACK_IMPORTED_MODULE_0__.GraphQLClient("https://api-ca-central-1.hygraph.com/v2/cl76cbzf567do01uobh04hzvo/master");
const graphqlAPI = "https://api-ca-central-1.hygraph.com/v2/cl76cbzf567do01uobh04hzvo/master";
const getPosts = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      postsConnection (orderBy: createdAt_DESC) {
        edges {
          node {
            title
            slug
            category {
              name
              slug
            }
            tags {
              name
              slug
            }
            excerpt
            address
            featuredImage {
              url
            }
            createdAt
            content {
              raw
            }
          }
        }
      }
    }
  `;
    const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query);
    return result.postsConnection.edges;
};
const getPostDetails = async (slug)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query getPostDetails($slug: String!) {
      post(
        where: { slug: $slug }
      ) {
        createdAt
        slug
        title
        excerpt
        tags {
          name
          slug
        }
        featuredImage {
          url
        }
        category {
          name
          slug
        }
        content {
          html
        }
        localizations(locales: uk_UA) {
          title
          excerpt
          tags {
            name
          }
          content {
            html
          }
        }
      }
    }
  `;
    const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query, {
        slug
    });
    return result.post;
};
const getPostDetailsUA = async (slug)=>{
    const query = gql`
    query getPostDetailsUA($slug: String!) {
      post(where: { slug: $slug }) {
        title
        excerpt
        createdAt
        slug
        featuredImage {
          url
        }
        category {
          name
          slug
        }
        localizations(locales: uk_UA) {
          title
          excerpt
          tags {
            name
          }
          content {
            html
          }
        }
      }
    }
  `;
    const result = await request(graphqlAPI, query, {
        slug
    });
    return result.post;
};
const getRelatedPosts = async (category, tags, slug)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query GetPostDetails($slug: String!, $category: String!, $tags: [String!]) {
      posts (
        where: {
          category: { name: $category },
          AND: { slug_not: $slug,
          tags_some: { slug_in: $tags }}
        }
        last: 9
      ) {
        title
        createdAt
        slug
        excerpt
        address
        featuredImage {
          url
        }
        tags {
          name
        }
        localizations(locales: uk_UA) {
          title
          excerpt
          address
          tags {
            name
          }
        }
      }
    }
    `;
    const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query, {
        category,
        tags,
        slug
    });
    return result.posts;
};


/***/ })

};
;