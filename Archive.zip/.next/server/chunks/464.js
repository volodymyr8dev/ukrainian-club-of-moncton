"use strict";
exports.id = 464;
exports.ids = [464];
exports.modules = {

/***/ 464:
/***/ ((module) => {

module.exports = JSON.parse('{"want-volunteer":"Do you want to volunteer with us?","donate-now":"Donate now","contact-us":"Contact us: ","email":"Email: ","address":"Address: ","volunteer-with":"Volunteer with us","home":"Home","info":"Info","events":"Events","our-help":"Our help","about":"About","what-looking-for":"What you\'re looking for seems to be missing.","try-below":" Try something below.","go-home":"Go to home","previous":"Previous page"}');

/***/ })

};
;