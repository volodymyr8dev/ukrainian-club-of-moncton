"use strict";
exports.id = 884;
exports.ids = [884];
exports.modules = {

/***/ 3884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "B": () => (/* binding */ HeadingToggler)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./assets/images/prev-arrow.svg
/* harmony default export */ const prev_arrow = ({"src":"/_next/static/media/prev-arrow.40718081.svg","height":64,"width":64});
;// CONCATENATED MODULE: ./assets/images/next-arrow.svg
/* harmony default export */ const next_arrow = ({"src":"/_next/static/media/next-arrow.c92313af.svg","height":64,"width":64});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8027);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/utils/HeadingToggler.jsx




const HeadingToggler = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between items-center pb-12 md:pb-16",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "font-proximaNova400 text-[32px] md:text-[40px] uppercase tracking-wider",
                        children: props.heading
                    })
                }),
                props.relatedPosts > 6 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "hidden md:flex gap-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: `${props.togglerPrevClass} cursor-pointer`,
                            src: prev_arrow,
                            alt: "previous",
                            width: 64,
                            height: 64
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: `${props.togglerNextClass} cursor-pointer`,
                            src: next_arrow,
                            alt: "next",
                            width: 64,
                            height: 64
                        })
                    ]
                })
            ]
        })
    });
};


/***/ })

};
;