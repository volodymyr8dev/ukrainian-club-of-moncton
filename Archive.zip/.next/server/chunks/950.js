"use strict";
exports.id = 950;
exports.ids = [950];
exports.modules = {

/***/ 950:
/***/ ((module) => {

module.exports = JSON.parse('{"want-volunteer":"Хочете бути нашим волонтером?","donate-now":"Зробити пожертву","contact-us":"Зв\'язатися з нами: ","email":"Електронна пошта: ","address":"Адреса: ","volunteer-with":"Будь волонтером разом з нами","home":"Головна","info":"Інформація","events":"Події","our-help":"Наша допомога","about":"Про нас","what-looking-for":"Здається немає того, що ви шукаєте","try-below":" Спробуйте щось інше.","go-home":"До головної","previous":"Попередня сторінка"}');

/***/ })

};
;