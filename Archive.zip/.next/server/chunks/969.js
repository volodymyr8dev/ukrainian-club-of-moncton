"use strict";
exports.id = 969;
exports.ids = [969];
exports.modules = {

/***/ 2969:
/***/ ((module) => {

module.exports = JSON.parse('{"learn-more":"Learn more"}');

/***/ })

};
;