exports.id = 52;
exports.ids = [52];
exports.modules = {

/***/ 7655:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./en/common": [
		464,
		464
	],
	"./en/common.json": [
		464,
		464
	],
	"./en/how": [
		2969,
		969
	],
	"./en/how.json": [
		2969,
		969
	],
	"./ua/common": [
		950,
		950
	],
	"./ua/common.json": [
		950,
		950
	],
	"./ua/how": [
		6171,
		171
	],
	"./ua/how.json": [
		6171,
		171
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(() => {
		return __webpack_require__.t(id, 3 | 16);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 7655;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 487:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Am": () => (/* binding */ REVALIDATION_TIME_PAGINATION),
/* harmony export */   "Bk": () => (/* binding */ LOCALE_UA),
/* harmony export */   "JI": () => (/* binding */ REVALIDATION_TIME_POST)
/* harmony export */ });
/* unused harmony export LOCALE_EN */
const REVALIDATION_TIME_POST = 10 * 60; // 10 min
const REVALIDATION_TIME_PAGINATION = 1 * 60; // 1 min
const LOCALE_EN = "en";
const LOCALE_UA = "ua";


/***/ }),

/***/ 3947:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ getTexts)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7663);


const GET_TEXTS_QUERY = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
  query MyQuery($skip:Int!) {
    englishTexts: texts(first: 2000, locales: en,skip:$skip) {
      name
      textContent
      slug
    }
    ukrainianTexts: texts(first: 2000, locales: uk_UA,skip:$skip) {
      name
      textContent
      slug
    }
  }
`;
const GET_TEXTS_EN = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
  query MyQuery($skip:Int!)  {
    englishTexts: texts(first: 2000, locales: en,skip:$skip) {
      name
      textContent
      slug
    }
  }
`;
const GET_TEXTS_UA = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
  query MyQuery($skip:Int!) {
    ukrainianTexts: texts(first: 2000, locales: uk_UA,skip:$skip) {
      name
      textContent
      slug
    }
  }
`;
const getTexts = (lang, skip = 0)=>{
    let GET_TEXTS = GET_TEXTS_QUERY;
    if (lang) {
        lang === "en" ? GET_TEXTS = GET_TEXTS_EN : GET_TEXTS = GET_TEXTS_UA;
    }
    let { data , loading , error  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useQuery)(GET_TEXTS, {
        variables: {
            skip
        }
    });
    if (loading) console.log("Fetching data...");
    if (error) console.log("error: ", error);
    if (lang) {
        data = lang === "en" ? data?.englishTexts : data?.ukrainianTexts;
    }
    if (data) {
        data = (0,_helpers__WEBPACK_IMPORTED_MODULE_1__/* .checkTypeOfData */ .v)(data).reduce((a, c)=>(a[c.slug] = c.textContent, a), {});
    }
    return {
        data,
        loading,
        error
    };
};


/***/ }),

/***/ 7663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ isPostInvalid),
/* harmony export */   "v": () => (/* binding */ checkTypeOfData)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(487);

function isPostInvalid(locale, post) {
    return !post || locale === _constants__WEBPACK_IMPORTED_MODULE_0__/* .LOCALE_UA */ .Bk && (!post.localizations || post.localizations.length === 0);
}
const checkTypeOfData = (data)=>{
    return Array.isArray(data) ? data : lang == "en" ? data.englishTexts : data.ukrainianTexts;
};


/***/ }),

/***/ 608:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"locales":["en","ua"],"defaultLocale":"en","pages":{"*":["common"],"/how":["how"]}}');

/***/ })

};
;