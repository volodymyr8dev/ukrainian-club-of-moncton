export const REVALIDATION_TIME_POST = 10 * 60; // 10 min
export const REVALIDATION_TIME_PAGINATION = 1 * 60; // 1 min

export const LOCALE_EN = 'en';
export const LOCALE_UA = 'ua';